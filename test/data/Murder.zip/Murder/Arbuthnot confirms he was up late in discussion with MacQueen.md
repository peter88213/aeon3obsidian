




- **Participant** : [[Hercule Poirot]]
- **Relates to** : [[MacQueen talks politics with Colonel Arbuthnot]]
- **Participant** : [[Colonel Arbuthnot]]
