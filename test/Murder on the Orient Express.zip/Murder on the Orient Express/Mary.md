Mary

Countess Andrenyi’s governess

- Associate: [[Countess]]

1908-02-12

00:00