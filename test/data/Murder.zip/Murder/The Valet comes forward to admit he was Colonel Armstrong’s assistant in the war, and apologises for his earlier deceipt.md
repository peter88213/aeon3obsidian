---
date: 1933-02-07
time: 1933-02-07T19:40:00
---


- **When** : Tuesday 7 March 1933 19:40
- **Lasts** : 5 minutes

- **Participant** : [[The Valet]]
- **Witness** : [[Dr. Constantine]]
- **Clue** : [[Ratchett’s true identity]]
- **Participant** : [[Hercule Poirot]]
- **Witness** : [[M. Bouc]]
