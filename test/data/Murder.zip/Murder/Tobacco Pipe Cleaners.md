---
aliases: 
  - Pipe
---




- **Relevance** : Circumstancial
