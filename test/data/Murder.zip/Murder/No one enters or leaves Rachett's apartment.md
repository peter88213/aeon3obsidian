---
date: 1933-02-07
time: 1933-02-07T00:00:00
---


---

According to the Conductor

---

- **When** : Tuesday 7 March 1933 0:00


- **Witness** : [[Mr Ratchett]]
- **Witness** : [[The Conductor]]
