---
aliases: 
  - Foscarelli
---


---

Chauffer to the Armstrong household at the time of Daisy’s kidnapping.

---



- **Nickname** : The Italian
- **Gender** : Male
- **Motivation** : Chauffer to the Armstrong household at the time of Daisy’s kidnapping.
- **Nationality** : Italian
- **Characteristics** : Excessively talkative, prone to drift off-topic


- **Associate** : [[Colonel Armstrong]]
