- Participant: [[Poirot]]

- Clue: [[Locked Compartment]]