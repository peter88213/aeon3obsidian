---
aliases: 
  - Valet
---


---

Acting as Mr Ratchett’s personal valet, he was the personal servant of Colonel Armstrong, Daisy’s father.

---



- **Nationality** : British
- **Real Name** : Edward Masterman
- **Gender** : Male
- **Characteristics** : Unemotional.
- **Motivation** : He was the personal servant of Colonel Armstrong, Daisy’s father.


- **Associate** : [[Mr Ratchett]]
- **Associate** : [[Colonel Armstrong]]
