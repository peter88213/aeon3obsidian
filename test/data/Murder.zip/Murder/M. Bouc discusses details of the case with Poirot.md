---
date: 1933-02-07
time: 1933-02-07T10:45:00
---


- **When** : Tuesday 7 March 1933 10:45
- **Lasts** : 25 minutes

- **Participant** : [[Hercule Poirot]]
- **Participant** : [[Dr. Constantine]]
- **Participant** : [[M. Bouc]]


- [[M. Bouc observes the carriage was locked and chained on the inside, and it is apparent the murderer is still on the train]]
- [[Suicide is ruled out, as Ratchett was stabbed 10-15 times. The coroner determines the death occurred between midnight and 2am]]
- [[M. Bouc observes that the window was left open, but as there are no footprints outside, this is an obvious ruse]]
