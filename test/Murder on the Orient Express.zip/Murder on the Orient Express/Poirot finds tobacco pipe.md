Matches Colonel Arthbutnots

- Participant: [[Poirot]]

- Clue: [[Tobacco Pipe Cleaners]]

#Clue

#Pipe

1933-02-07

11:39