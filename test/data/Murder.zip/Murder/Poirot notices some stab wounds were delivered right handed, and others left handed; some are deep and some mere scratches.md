---
date: 1933-02-07
time: 1933-02-07T11:30:00
---


- **When** : Tuesday 7 March 1933 11:30


- **Clue** : [[Stab wounds]]
- **Participant** : [[Hercule Poirot]]
