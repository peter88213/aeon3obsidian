- Participant: [[Mary]]

- Participant: [[Poirot]]

[[Mary Debenham denies owning the scarlet dressing gown]]

1933-02-07

14:50

10 minutes