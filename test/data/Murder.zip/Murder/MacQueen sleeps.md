---
date: 1933-02-07
time: 1933-02-07T01:45:00
tags: 
  - No_Alibi
---


- **When** : Tuesday 7 March 1933 1:45


- **Status** : Uncorroborated


- **Testimony** : [[Hector MacQueen's Testimony]]
- **Participant** : [[Hector MacQueen]]
