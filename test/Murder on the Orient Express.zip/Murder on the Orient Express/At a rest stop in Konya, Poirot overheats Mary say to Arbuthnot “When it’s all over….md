- Witness: [[Poirot]]

- Participant: [[Arbuthnot]]

- Participant: [[Mary]]