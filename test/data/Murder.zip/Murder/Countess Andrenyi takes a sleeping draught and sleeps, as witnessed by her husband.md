---
date: 1933-02-06
time: 1933-02-06T23:00:00
tags: 
  - Alibi
---


- **When** : Monday 6 March 1933 23:00
- **Lasts** : 9 hours

- **Status** : Corroborated


- **Participant** : [[Countess Andrenyi]]
- **Testimony** : [[Countess Andrenyi's Testimony]]
- **Witness** : [[Count Andrenyi]]
- **Testimony** : [[Count Andrenyi's Testimony]]
