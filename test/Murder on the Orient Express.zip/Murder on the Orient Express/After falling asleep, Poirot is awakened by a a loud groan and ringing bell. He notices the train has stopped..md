- Participant: [[Poirot]]

1933-02-07

00:37