---
date: 1933-02-06
time: 1933-02-06T22:00:00
tags: 
  - Alibi
---


- **When** : Monday 6 March 1933 22:00


- **Status** : Uncorroborated


- **Testimony** : [[Hildegarde Schmidt's Testimony]]
- **Participant** : [[Hildegarde Schmidt]]
