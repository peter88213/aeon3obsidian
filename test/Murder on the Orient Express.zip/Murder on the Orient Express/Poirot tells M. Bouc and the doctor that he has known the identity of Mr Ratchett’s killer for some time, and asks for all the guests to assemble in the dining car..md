- Participant: [[Poirot]]

- Witness: [[M. Bouc]]

- Witness: [[Coroner]]