- Testimony: [[Hector MacQueen's Testimony]]

- Clue: [[Ratchett’s true identity]]

- Participant: [[Arbuthnot]]

- Participant: [[Poirot]]