- Participant: [[Poirot]]

- Participant: [[Mary]]

- Witness: [[M. Bouc]]

- Witness: [[Coroner]]

- Clue: [[Ratchett’s true identity]]

- Witness: [[Arbuthnot]]

1933-02-07

19:30