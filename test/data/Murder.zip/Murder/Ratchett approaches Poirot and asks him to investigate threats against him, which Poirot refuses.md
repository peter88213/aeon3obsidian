




- **Participant** : [[Hercule Poirot]]
- **Participant** : [[Mr Ratchett]]
