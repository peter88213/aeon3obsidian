---
date: 1933-02-07
time: 1933-02-07T19:35:00
---


- **When** : Tuesday 7 March 1933 19:35
- **Lasts** : 5 minutes

- **Witness** : [[M. Bouc]]
- **Clue** : [[Ratchett’s true identity]]
- **Participant** : [[Antonio Foscarelli]]
- **Participant** : [[Hercule Poirot]]
- **Witness** : [[Dr. Constantine]]
