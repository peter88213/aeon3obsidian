As Mr. Ratchett does not speak French, this is to imply to Poirot that he was already dead at this point



- Witness: [[Poirot]]

- Participant: [[Conductor]]

- Murder Theory: [[True Crime]]

- Relates to: [[French reply from door]]

- Clue: [[French reply from door]]

1933-02-07

00:37