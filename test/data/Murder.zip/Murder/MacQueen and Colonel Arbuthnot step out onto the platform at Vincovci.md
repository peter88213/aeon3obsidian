---
date: 1933-02-07
time: 1933-02-07T00:00:00
tags: 
  - Alibi
---


- **When** : Tuesday 7 March 1933 0:00


- **Status** : Corroborated


- **Testimony** : [[Hector MacQueen's Testimony]]
- **Testimony** : [[Colonel Arbuthnot's Testimony]]
- **Participant** : [[Hector MacQueen]]
- **Participant** : [[Colonel Arbuthnot]]
