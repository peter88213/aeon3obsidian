---
aliases: 
  - Handkerchief
---




- **Relevance** : Circumstancial
