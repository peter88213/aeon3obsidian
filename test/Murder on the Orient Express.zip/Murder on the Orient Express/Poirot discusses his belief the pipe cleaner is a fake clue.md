- Relates to: [[Tobacco Pipe Cleaners]]

- Participant: [[Poirot]]

- Participant: [[Coroner]]

- Participant: [[M. Bouc]]