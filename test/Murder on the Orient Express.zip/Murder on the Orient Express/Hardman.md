Hardman

The lover of Daisy Armstrong’s nurse maid

- Partner: [[Nursemaid]]

1900-02-13

00:00