- Participant: [[Poirot]]

- Participant: [[M. Bouc]]

- Participant: [[Coroner]]

- Clue: [[Stab wounds]]

1933-02-07

10:45

25 minutes