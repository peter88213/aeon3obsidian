




- **Clue** : [[Scarlett Dressing Gown]]
