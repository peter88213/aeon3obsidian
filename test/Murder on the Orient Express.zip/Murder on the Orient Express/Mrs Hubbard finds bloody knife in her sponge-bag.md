- Witness: [[Poirot]]

- Participant: [[Hubbard]]

- Clue: [[Bloody knife]]

#Murder_Weapon

1933-02-07

15:30