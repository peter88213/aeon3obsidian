---
date: 1933-02-07
time: 1933-02-07T16:00:00
tags: 
  - Clue
  - Imposter_in_Kimono
---


- **When** : Tuesday 7 March 1933 16:00


- **Status** : Established Fact


- **Clue** : [[Scarlett Dressing Gown]]
- **Participant** : [[Hercule Poirot]]
