




- **Participant** : [[Hercule Poirot]]
- **Witness** : [[M. Bouc]]
- **Clue** : [[Fake conductor]]
