---
date: 1855-02-24
time: 1855-02-24T00:00:00
aliases: 
  - Princess
---


---

Sonia Armstrong’s godmother

---

- **When** : Saturday 24 March 1855 00:00


- **Nationality** : Russian
- **Characteristics** : Ugly, but strong-willed.
- **Motivation** : She is the godmother of Sonia Armstrong, Daisy’s mother.
- **Gender** : Female


- **Friend** : [[Sonia Armstrong]]
