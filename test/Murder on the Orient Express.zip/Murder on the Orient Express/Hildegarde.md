Hildegarde

Lady’s maid working for Princess Dragomiroff.