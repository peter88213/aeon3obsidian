---
date: 1933-02-07
time: 1933-02-07T14:00:00
---


- **When** : Tuesday 7 March 1933 14:00
- **Lasts** : 10 minutes

- **Participant** : [[Count Andrenyi]]
- **Participant** : [[Hercule Poirot]]
- **Participant** : [[Countess Andrenyi]]


- [[The Countess claims her husband smokes cigarettes and cigars, but not a pipe]]
- [[The Countess claims her dressing gown is yellow]]
