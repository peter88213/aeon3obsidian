- Participant: [[Princess]]

- Participant: [[Poirot]]

- Clue: [[Ratchett’s true identity]]