---
date: 1933-02-07
time: 1933-02-07T19:20:00
---


- **When** : Tuesday 7 March 1933 19:20


- **Witness** : [[M. Bouc]]
- **Participant** : [[Hercule Poirot]]
- **Clue** : [[Overheard “When it’s all over]]
- **Participant** : [[Colonel Arbuthnot]]
- **Witness** : [[Dr. Constantine]]
