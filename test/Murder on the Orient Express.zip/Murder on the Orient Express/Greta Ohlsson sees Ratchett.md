This was the last time Ratchett was seen alive

- Participant: [[Ratchett]]

- Participant: [[Greta]]

- Witness: [[Hubbard]]

1933-02-06

22:39