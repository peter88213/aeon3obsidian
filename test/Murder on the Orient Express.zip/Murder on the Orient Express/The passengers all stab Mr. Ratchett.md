They were all in on it. Countess Andrenyi, though aware of the plan, was the only one that did not take part.

The pipe and handkerchief were left in the compartment to confuse Poirot.

This explains the different times of death and the different types of stabbing





- Participant: [[Hardman]]

- Participant: [[MacQueen]]

- Participant: [[Mary]]

- Participant: [[Conductor]]

- Participant: [[Foscarelli]]

- Participant: [[Ratchett]]

- Participant: [[Valet]]

- Participant: [[Greta]]

- Participant: [[Princess]]

- Participant: [[Arbuthnot]]

- Participant: [[Hubbard]]

- Participant: [[Count]]

- Participant: [[Hildegarde]]

- Murder Theory: [[True Crime]]

#Murder_Weapon

#Hankerchief

#Pipe

1933-02-07

01:45

15 minutes