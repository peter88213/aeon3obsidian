---
date: 1933-02-07
time: 1933-02-07T02:00:00
tags: 
  - Burnt_Paper
---


- **When** : Tuesday 7 March 1933 02:00


- **Status** : Established Fact


- **Clue** : [[Threatening letters]]
- **Participant** : [[Mary Debenham]]
- **Murder Theory** : [[The Real Crime]]
- **Participant** : [[Princess Dragonmiroff]]
- **Participant** : [[Count Andrenyi]]
- **Participant** : [[Hector MacQueen]]
- **Participant** : [[Cyrus Hardman]]
- **Participant** : [[The Conductor]]
- **Participant** : [[Colonel Arbuthnot]]
- **Participant** : [[Mrs Hubbard]]
- **Participant** : [[The Valet]]
- **Participant** : [[Greta Ohlsson]]
- **Participant** : [[Hildegarde Schmidt]]
- **Participant** : [[Antonio Foscarelli]]
