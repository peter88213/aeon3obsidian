- Clue: [[Fake conductor]]

- Participant: [[Hildegarde]]