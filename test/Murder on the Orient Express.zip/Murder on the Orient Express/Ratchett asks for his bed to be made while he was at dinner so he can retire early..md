- Testimony: [[Hector MacQueen's Testimony]]

- Participant: [[Ratchett]]

- Participant: [[Conductor]]

1933-02-06

21:00