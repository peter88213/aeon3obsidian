---
aliases: 
  - Global
---


---

Global events applicable across all arcs

---

