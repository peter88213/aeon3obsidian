---
date: 1933-02-06
time: 1933-02-06T21:00:00
---


---

He asks while he was at dinner so he can retire early.

---

- **When** : Monday 6 March 1933 21:00


- **Testimony** : [[Hector MacQueen's Testimony]]
- **Participant** : [[Mr Ratchett]]
- **Participant** : [[The Conductor]]
