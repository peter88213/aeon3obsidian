




- **Clue** : [[Ratchett’s true identity]]
- **Participant** : [[Hercule Poirot]]
- **Participant** : [[Hector MacQueen]]
