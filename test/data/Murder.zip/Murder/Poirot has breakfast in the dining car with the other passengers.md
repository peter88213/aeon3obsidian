---
date: 1933-02-07
time: 1933-02-07T09:45:00
---


---

He observes that they are all nervously contacting family and friends.

---

- **When** : Tuesday 7 March 1933 09:45
- **Lasts** : 1 hours

- **Participant** : [[Hercule Poirot]]
