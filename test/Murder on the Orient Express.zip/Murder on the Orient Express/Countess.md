Countess

Sonia Armstrong’s sister. With her strongest connection to Daisy Armstrong, she does not actively participate in the murder.

- Spouse: [[Count]]

- Sibling: [[Sonia Armstrong]]

1912-02-11

00:00