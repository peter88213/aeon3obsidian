---
date: 1933-02-06
time: 1933-02-06T22:39:00
---


---

She asks before she goes to bed

---

- **When** : Monday 6 March 1933 22:39


- **Participant** : [[Mrs Hubbard]]
- **Testimony** : [[Mrs Hubbard's Testimony]]
- **Participant** : [[Greta Ohlsson]]
