Ratchett

Real name Cassetti, kidnapped and murdered Daisy Armstrong.

- Relates to: [[Central Crime The Murder of Daisy Armstrong]]

1868-02-20

00:00

23728 days