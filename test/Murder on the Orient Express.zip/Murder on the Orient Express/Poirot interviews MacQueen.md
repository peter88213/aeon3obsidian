- Participant: [[MacQueen]]

- Participant: [[Poirot]]

[[Poirot informs MacQueen of Ratchett’s real identity. MacQueen reacts with surprise, and reveals his connection to the Armstrong case.]]

1933-02-07

13:10

10 minutes