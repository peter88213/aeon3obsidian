




- **Participant** : [[Hercule Poirot]]
- **Participant** : [[Dr. Constantine]]
- **Participant** : [[M. Bouc]]
