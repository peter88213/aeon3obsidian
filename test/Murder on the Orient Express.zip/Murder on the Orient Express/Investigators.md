[[Coroner]]

[[M. Bouc]]

[[Poirot]]