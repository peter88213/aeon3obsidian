A friend of Poirot’s who formerly worked for Belgian police, and is now Director of the company running the Orient Express.



He prematurely seizes on circumstancial evidence, acting as a “Dr Watson” within the plot. His primary purpose is to have Poirot correct him and explain his thoughts to him.