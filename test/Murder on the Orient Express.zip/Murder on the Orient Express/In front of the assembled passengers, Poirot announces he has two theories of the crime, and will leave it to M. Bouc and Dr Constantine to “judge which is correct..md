- Participant: [[Poirot]]

- Witness: [[Foscarelli]]

- Witness: [[Arbuthnot]]

- Witness: [[Count]]

- Witness: [[Countess]]

- Witness: [[Hardman]]

- Witness: [[Coroner]]

- Witness: [[Greta]]

- Witness: [[MacQueen]]

- Witness: [[Hildegarde]]

- Witness: [[M. Bouc]]

- Witness: [[Mary]]

- Witness: [[Hubbard]]

- Witness: [[Princess]]

- Witness: [[Conductor]]

- Witness: [[Valet]]

[[M. Bouc and Dr Constantine express shock and doubt at this theory, given it runs contrary to much of the evidence and theories they have seen earlier]]

[[Poirot then proposes a second possible theory, that all of the passengers colluded and participated in the murder to exact justice against Ratchett.]]

[[Finally understanding why Poirot outlined his first potential solution, M. Bouc and Dr Constantine agree to go along with Poirot’s conspiracy, and present the decoy solution to police after all.]]

[[Poirot concludes the smashed watch was set to a fake time, and that MacQueen had lied about Ratchett not speaking French to make Poirot think Ratchett was dead at 1237am, whereas the true murder occurred closer to 200am.]]

[[Linda Arden confirms many details of Poirot’s theory, and confirms the remaining connections between the passengers and the Armstrong family. She insists it was an act of justice and not revenge.]]

[[Poirot concludes the threatening letters, unknown assailant, conductor’s uniform and red dressing gown were all decoys designed to confuse the investigation.]]

[[Poirot concludes that Linda Arden, Daisy’s grandmother, was the mastermind behind her plan, at which point Mrs Hubbard announces herself as Linda.]]

[[Poirot proposes one possible theory, involving an unknown assailant who snuck onto the train, murdered Ratchett, discarded the uniform in Hildegarde’s luggage and left the train]]

[[Poirot determines that of the 13 guests who delivered 12 stab wounds, it was the Countess that did not take part, as she was the person with the greatest motive and her husband instead took her place.]]

[[Poirot covers the known facts of the case, including the time of murder and that it was believed no one had departed the train.]]

1933-02-07

20:00

30 minutes