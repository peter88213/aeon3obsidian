- Participant: [[Conductor]]

- Testimony: [[The Conductor's Testimony]]

- Participant: [[Hubbard]]

- Testimony: [[Mrs Hubbard's Testimony]]

- Witness: [[Poirot]]

- Relates to: [[Intruder in Mrs Hubbard’s apartment]]

#Alibi

#Clue

1933-02-07

01:17

8 minutes