---
date: 1933-02-07
time: 1933-02-07T01:35:00
tags: 
  - Clue
  - Imposter_in_Kimono
---


- **When** : Tuesday 7 March 1933 1:35


- **Status** : Established Fact


- **Clue** : [[Scarlett Dressing Gown]]
- **Participant** : [[Hercule Poirot]]
- **Witness** : [[Colonel Arbuthnot]]
- **Witness** : [[Hector MacQueen]]
- **Witness** : [[The Conductor]]
