---
aliases: 
  - Knife
---




- **Relevance** : Circumstancial
