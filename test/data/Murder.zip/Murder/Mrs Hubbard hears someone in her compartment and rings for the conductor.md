---
date: 1933-02-07
time: 1933-02-07T01:17:00
tags: 
  - Alibi
  - Clue
---


- **When** : Tuesday 7 March 1933 01:17
- **Lasts** : 8 minutes

- **Status** : Established Fact


- **Witness** : [[Cyrus Hardman]]
- **Clue** : [[Intruder in Mrs Hubbard’s apartment]]
- **Participant** : [[The Conductor]]
- **Witness** : [[Hercule Poirot]]
- **Participant** : [[Hercule Poirot]]
- **Participant** : [[Mrs Hubbard]]
- **Testimony** : [[Mrs Hubbard's Testimony]]
