




- **Clue** : [[Fake conductor]]
- **Participant** : [[Hildegarde Schmidt]]
