- Participant: [[Poirot]]

- Participant: [[Arbuthnot]]

- Witness: [[M. Bouc]]

- Witness: [[Coroner]]

- Clue: [[Ratchett’s true identity]]

1933-02-07

19:23

2 minutes