- Participant: [[Poirot]]

- Clue: [[Stab wounds]]

1933-02-07

11:30