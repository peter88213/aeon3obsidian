- Participant: [[Poirot]]

- Participant: [[M. Bouc]]

- Participant: [[Coroner]]

[[M. Bouc observes the carriage was locked and chained on the inside, and it is apparent the murderer is still on the train.]]

[[Suicide is ruled out, as Ratchett was stabbed 10-15 times. The coroner determines the death occurred between midnight and 2am.]]

[[M. Bouc observes that the window was left open, but as there are no footprints outside, this is an obvious ruse.]]

1933-02-07

10:45

25 minutes