




- **Participant** : [[Dr. Constantine]]
- **Participant** : [[M. Bouc]]
- **Participant** : [[Hercule Poirot]]
- **Relates to** : [[Handkerchief with “H” monogram]]
