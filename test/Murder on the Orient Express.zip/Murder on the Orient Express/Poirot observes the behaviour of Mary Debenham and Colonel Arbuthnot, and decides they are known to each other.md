- Participant: [[Poirot]]

- Participant: [[Arbuthnot]]

- Participant: [[Mary]]