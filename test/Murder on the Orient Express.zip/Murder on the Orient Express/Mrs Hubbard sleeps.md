- Testimony: [[Mrs Hubbard's Testimony]]

- Participant: [[Hubbard]]

#No_Alibi

1933-02-06

22:40

157 minutes