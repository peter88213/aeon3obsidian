




- **Clue** : [[Tobacco Pipe Cleaners]]
