




- **Participant** : [[Greta Ohlsson]]
- **Participant** : [[Hercule Poirot]]
