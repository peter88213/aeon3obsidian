---
date: 1933-02-07
time: 1933-02-07T13:50:00
---


- **When** : Tuesday 7 March 1933 13:50


- **Participant** : [[Princess Dragonmiroff]]
- **Participant** : [[Hercule Poirot]]


- [[After Poirot reveals Ratchett’s identitiy, Princess Dragomiroff reveals she knew Daisy’s grandmother, Linda Arden]]
- [[Princess Dragomiroff claims her dressing gown is black satin]]
