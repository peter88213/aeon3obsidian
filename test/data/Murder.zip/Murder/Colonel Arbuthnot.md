---
date: 1865-02-21
time: 1865-02-21T00:00:00
aliases: 
  - Arbuthnot
---


---

A friend of Daisy Armstrong’s father.

---

- **When** : Tuesday 21 March 1865 0:00


- **Nationality** : British
- **Characteristics** : Honourable and slightly stupid, according to Poirot.
- **Motivation** : A friend of Daisy Armstrong’s father, Colonel Armstrong.
- **Gender** : Male


- **Friend** : [[Colonel Armstrong]]
