




- **Participant** : [[Hercule Poirot]]
- **Participant** : [[Colonel Arbuthnot]]
- **Testimony** : [[Hector MacQueen's Testimony]]
- **Clue** : [[Tobacco Pipe Cleaners]]
