---
date: 1933-02-06
time: 1933-02-06T05:00:00
---


- **When** : Monday 6 March 1933 05:00


- **Status** : Established Fact


- **Story Arc** : [[Train Movements]]
