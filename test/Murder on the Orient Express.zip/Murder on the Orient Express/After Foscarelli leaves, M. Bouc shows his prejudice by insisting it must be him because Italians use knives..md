- Participant: [[Poirot]]

- Participant: [[M. Bouc]]