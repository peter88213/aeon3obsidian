- Participant: [[Poirot]]

- See also: [[After multiple passengers hear a groan, the Conductor answers Ratchett’s ringing bell, and Rachett replies in French to assure him he is okay.]]

- Participant: [[Conductor]]

- Clue: [[French reply from door]]