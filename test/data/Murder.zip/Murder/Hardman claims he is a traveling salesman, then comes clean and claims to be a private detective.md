




- **Participant** : [[Cyrus Hardman]]
- **Participant** : [[Hercule Poirot]]
