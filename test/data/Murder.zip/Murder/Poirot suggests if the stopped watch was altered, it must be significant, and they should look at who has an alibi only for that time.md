




- **Clue** : [[Smashed Watch showing 1245]]
- **Participant** : [[Dr. Constantine]]
- **Participant** : [[Hercule Poirot]]
- **Participant** : [[M. Bouc]]
