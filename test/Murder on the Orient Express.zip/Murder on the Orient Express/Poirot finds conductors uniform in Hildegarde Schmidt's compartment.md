- Participant: [[Poirot]]

- Witness: [[Hildegarde]]

- Clue: [[Fake conductor]]

#Clue

#Imposter_in_Conductor's_uniform

1933-02-07

15:55