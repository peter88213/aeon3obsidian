---
date: 1933-02-07
time: 1933-02-07T01:17:00
---


- **When** : Tuesday 7 March 1933 1:17


- **Status** : Known Lie


- **Participant** : [[Mrs Hubbard]]
- **Murder Theory** : [[Poirot’s Decoy Theory]]
- **Participant** : [[The Conductor]]
- **Participant** : [[Unknown Intruder]]
