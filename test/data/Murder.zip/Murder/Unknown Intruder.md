---
aliases: 
  - Intruder
---


---

The unknown murderer is a decoy invented by Poirot to allow the true murderers to escape punishment

---

