- Participant: [[Poirot]]

- Clue: [[Burnt letter mentioning Daisy Armstrong]]

#Burnt_Paper

1933-02-07

11:50