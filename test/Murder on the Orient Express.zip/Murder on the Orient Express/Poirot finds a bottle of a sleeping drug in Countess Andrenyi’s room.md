- Participant: [[Poirot]]

- Witness: [[Countess]]

- Witness: [[Count]]