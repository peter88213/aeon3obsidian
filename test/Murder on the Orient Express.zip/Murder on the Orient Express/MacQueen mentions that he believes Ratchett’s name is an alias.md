- Participant: [[Poirot]]

- Clue: [[Ratchett’s true identity]]

1933-02-07

11:10:06

19 minutes, 54 seconds