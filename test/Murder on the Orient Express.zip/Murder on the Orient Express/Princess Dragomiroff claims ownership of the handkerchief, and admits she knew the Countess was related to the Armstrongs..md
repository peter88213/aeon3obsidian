- Participant: [[Princess]]

- Participant: [[Poirot]]

- Witness: [[M. Bouc]]

- Witness: [[Coroner]]

- Clue: [[Handkerchief with “H” monogram]]

- Clue: [[Ratchett’s true identity]]

1933-02-07

19:15

5 minutes