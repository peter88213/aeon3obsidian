---
date: 1933-02-07
time: 1933-02-07T05:10:00
tags: 
  - No_Alibi
---


- **When** : Tuesday 7 March 1933 05:10
- **Lasts** : 2 hours, 50 minutes

- **Status** : Corroborated


- **Witness** : [[Greta Ohlsson]]
- **Participant** : [[Mary Debenham]]
- **Testimony** : [[Mary Debenham's Testimony]]
