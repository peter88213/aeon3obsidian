- Testimony: [[Hector MacQueen's Testimony]]

- Clue: [[Tobacco Pipe Cleaners]]

- Participant: [[Arbuthnot]]

- Participant: [[Poirot]]