- Participant: [[Poirot]]

- Participant: [[Valet]]

[[Poirot asks The Valet if he is a pipe smoker, but he claims he only smokes cigarettes]]

1933-02-07

13:20

10 minutes