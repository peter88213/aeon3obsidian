---
date: 1933-02-07
time: 1933-02-07T00:46:00
tags: 
  - Alibi
---


- **When** : Tuesday 7 March 1933 00:46
- **Lasts** : 29 minutes

- **Status** : Corroborated


- **Testimony** : [[Princess Dragomiroff's Testimony]]
- **Testimony** : [[Hildegarde Schmidt's Testimony]]
- **Participant** : [[Princess Dragonmiroff]]
- **Participant** : [[Hildegarde Schmidt]]
