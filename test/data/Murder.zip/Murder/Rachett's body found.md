---
date: 1933-02-07
time: 1933-02-07T10:40:00
---


- **When** : Tuesday 7 March 1933 10:40


- **Witness** : [[Mr Ratchett]]
- **Participant** : [[The Conductor]]
