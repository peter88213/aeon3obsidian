




- **Clue** : [[Scarlett Dressing Gown]]
- **Participant** : [[Hercule Poirot]]
- **Participant** : [[Mary Debenham]]
