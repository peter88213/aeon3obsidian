---
date: 1933-02-06
time: 1933-02-06T21:40:00
aliases: 
  - MacQueen takes down letters
---


---

This is observed by the Conductor, who states that no one else was seen entering Ratchett’s room that night.

---

- **When** : Monday 6 March 1933 21:40


- **Status** : Uncorroborated


- **Participant** : [[Mr Ratchett]]
- **Testimony** : [[The Conductor's Testimony]]
- **Testimony** : [[Hector MacQueen's Testimony]]
- **Participant** : [[Hector MacQueen]]
