




- **Participant** : [[Hercule Poirot]]
- **Clue** : [[Tobacco Pipe Cleaners]]
- **Participant** : [[The Valet]]
