---
aliases: 
  - Greta
---


---

Daisy Armstrong’s nurse

---



- **Nationality** : Swedish
- **Real Name** : 
- **Motivation** : She was Daisy Armstrong’s nurse.
- **Gender** : Female
- **Characteristics** : Sentimental and delicate.


- **Nurse** : [[Daisy Armstrong]]
