---
aliases: 
  - Imposter
---


---

Described as a small, dark man with a feminine voice by Hardman, which is later confirmed by Hildegarde Schmidt.

---



- **Relevance** : Red Herring


- **Witness** : [[Colonel Arbuthnot]]
- **Witness** : [[Hector MacQueen]]
- **Witness** : [[Cyrus Hardman]]
- **Witness** : [[Hildegarde Schmidt]]
- **Relates to** : [[Intruder in Mrs Hubbard’s apartment]]
