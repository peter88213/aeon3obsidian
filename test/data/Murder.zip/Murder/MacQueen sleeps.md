---
date: 1933-02-07
time: 1933-02-07T01:45:00
tags: 
  - No_Alibi
---


- **When** : Tuesday 7 March 1933 01:45
- **Lasts** : 6 hours

- **Status** : Uncorroborated


- **Testimony** : [[Hector MacQueen's Testimony]]
- **Participant** : [[Hector MacQueen]]
