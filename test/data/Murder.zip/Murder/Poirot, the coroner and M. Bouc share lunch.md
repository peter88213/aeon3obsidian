---
date: 1933-02-07
time: 1933-02-07T12:00:00
---


---

Over lunch, Poirot explains the identity of the victim and details of the Armstrong case.

---

- **When** : Tuesday 7 March 1933 12:00


- **Relates to** : [[Daisy’s Nursemaid]]
- **Participant** : [[Hercule Poirot]]
- **See also** : [[Central Crime The Murder of Daisy Armstrong]]
