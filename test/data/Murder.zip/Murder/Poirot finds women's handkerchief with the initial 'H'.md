---
date: 1933-02-07
time: 1933-02-07T11:37:00
tags: 
  - Clue
  - Hankerchief
---


- **When** : Tuesday 7 March 1933 11:37


- **Status** : Established Fact


- **Participant** : [[Hercule Poirot]]
- **Clue** : [[Handkerchief with “H” monogram]]
