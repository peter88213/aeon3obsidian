




- **Participant** : [[Greta Ohlsson]]
- **Participant** : [[Hercule Poirot]]
- **See also** : [[Mary Debenham sleeps]]
