---
date: 1933-02-07
time: 1933-02-07T20:27:00
---


- **When** : Tuesday 7 March 1933 20:27
- **Lasts** : 3 minutes

- **Witness** : [[Mary Debenham]]
- **Witness** : [[Antonio Foscarelli]]
- **Witness** : [[Cyrus Hardman]]
- **Witness** : [[The Conductor]]
- **Witness** : [[Count Andrenyi]]
- **Participant** : [[Hercule Poirot]]
- **Witness** : [[The Valet]]
- **Witness** : [[Dr. Constantine]]
- **Witness** : [[Greta Ohlsson]]
- **Witness** : [[Hector MacQueen]]
- **Witness** : [[Countess Andrenyi]]
- **Witness** : [[Princess Dragonmiroff]]
- **Witness** : [[Hildegarde Schmidt]]
- **Witness** : [[Colonel Arbuthnot]]
- **Witness** : [[Mrs Hubbard]]
- **Witness** : [[M. Bouc]]
