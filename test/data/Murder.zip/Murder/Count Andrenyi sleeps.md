---
date: 1933-02-06
time: 1933-02-06T23:10:00
tags: 
  - Partial_Alibi
---


---

This alibi does not cover the time period 1-1:15 am

---

- **When** : Monday 6 March 1933 23:10
- **Lasts** : 8 hours, 50 minutes

- **Status** : Uncorroborated


- **Testimony** : [[Count Andrenyi's Testimony]]
- **Participant** : [[Count Andrenyi]]
