---
date: 1933-02-06
time: 1933-02-06T21:15:00
tags: 
  - Train_Movement
---


- **When** : Monday 6 March 1933 21:15


- **Status** : Established Fact


- **Story Arc** : [[Train Movements]]
