




- **Participant** : [[M. Bouc]]
- **Participant** : [[Dr. Constantine]]
- **Clue** : [[Threatening letters]]
- **Participant** : [[Hercule Poirot]]
