---
date: 1933-02-06
time: 1933-02-06T22:30:00
tags: 
  - Alibi
---


---

This is confirmed by The Valet who shared his room

---

- **When** : Monday 6 March 1933 22:30


- **Status** : Corroborated


- **Witness** : [[The Valet]]
- **Testimony** : [[Antonio Foscarelli's Testimony]]
- **Participant** : [[Antonio Foscarelli]]
