




- **Participant** : [[Dr. Constantine]]
- **Participant** : [[M. Bouc]]
- **Participant** : [[Hercule Poirot]]
- **Relates to** : [[Scarlett Dressing Gown]]
