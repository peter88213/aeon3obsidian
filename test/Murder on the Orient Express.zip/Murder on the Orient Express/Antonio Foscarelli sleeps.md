- Participant: [[Foscarelli]]

- Witness: [[Valet]]

- Testimony: [[Antonio Foscarelli's Testimony]]

#No_Alibi

1933-02-07

04:00

4 hours