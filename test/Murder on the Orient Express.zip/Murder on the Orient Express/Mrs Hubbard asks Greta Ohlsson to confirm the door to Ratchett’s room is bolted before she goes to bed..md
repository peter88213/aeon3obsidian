- Testimony: [[Mrs Hubbard's Testimony]]

- Participant: [[Hubbard]]

- Participant: [[Greta]]

1933-02-06

22:39