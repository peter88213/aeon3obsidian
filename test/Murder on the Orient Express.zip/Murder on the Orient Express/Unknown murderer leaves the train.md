- Participant: [[Intruder]]

- Murder Theory: [[Poirot’s Decoy Theory]]

1933-02-07

00:25