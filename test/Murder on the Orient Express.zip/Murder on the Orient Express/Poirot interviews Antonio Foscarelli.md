- Participant: [[Poirot]]

- Participant: [[Foscarelli]]

[[Foscarelli confirms the story of the Valet, that they both remained in their compartment all night]]

1933-02-07

14:40

10 minutes