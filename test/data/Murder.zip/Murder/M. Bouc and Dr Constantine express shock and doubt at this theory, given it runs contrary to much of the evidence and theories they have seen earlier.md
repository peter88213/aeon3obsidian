---
date: 1933-02-07
time: 1933-02-07T20:06:00
---


- **When** : Tuesday 7 March 1933 20:06


- **Witness** : [[Hector MacQueen]]
- **Participant** : [[Hercule Poirot]]
- **Witness** : [[Colonel Arbuthnot]]
- **Witness** : [[Greta Ohlsson]]
- **Witness** : [[Hildegarde Schmidt]]
- **Witness** : [[Count Andrenyi]]
- **Witness** : [[Antonio Foscarelli]]
- **Witness** : [[Mrs Hubbard]]
- **Witness** : [[The Valet]]
- **Witness** : [[Mary Debenham]]
- **Witness** : [[Princess Dragonmiroff]]
- **Participant** : [[Dr. Constantine]]
- **Witness** : [[Cyrus Hardman]]
- **Witness** : [[The Conductor]]
- **Witness** : [[Countess Andrenyi]]
- **Participant** : [[M. Bouc]]
