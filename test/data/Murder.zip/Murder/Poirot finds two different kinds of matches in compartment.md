---
date: 1933-02-07
time: 1933-02-07T11:35:00
tags: 
  - Clue
  - Burnt_Paper
---


---

This indicates to him that something incriminating has been burnt

---

- **When** : Tuesday 7 March 1933 11:35


- **Status** : Established Fact


- **Clue** : [[Matches]]
- **Participant** : [[Hercule Poirot]]
