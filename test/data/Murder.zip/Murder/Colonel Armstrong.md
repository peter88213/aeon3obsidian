


---

Father of murder victim Daisy Armstrong

---

