- Testimony: [[Mrs Hubbard's Testimony]]

- Participant: [[Greta]]

- Testimony: [[Greta Ohlsson's Testimony]]

- Participant: [[Hubbard]]

#Alibi

1933-02-06

22:41

14 minutes