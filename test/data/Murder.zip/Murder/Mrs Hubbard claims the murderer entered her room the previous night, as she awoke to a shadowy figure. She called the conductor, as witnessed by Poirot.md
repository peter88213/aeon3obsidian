




- **Participant** : [[Mrs Hubbard]]
- **See also** : [[Mrs Hubbard hears someone in her compartment and rings for the conductor]]
- **Participant** : [[Hercule Poirot]]
- **Clue** : [[Intruder in Mrs Hubbard’s apartment]]
