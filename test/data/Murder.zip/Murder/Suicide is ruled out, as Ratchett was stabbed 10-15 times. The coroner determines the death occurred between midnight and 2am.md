---
date: 1933-02-07
time: 1933-02-07T10:45:00
---


- **When** : Tuesday 7 March 1933 10:45
- **Lasts** : 25 minutes

- **Participant** : [[Dr. Constantine]]
- **Clue** : [[Stab wounds]]
- **Participant** : [[M. Bouc]]
- **Participant** : [[Hercule Poirot]]
