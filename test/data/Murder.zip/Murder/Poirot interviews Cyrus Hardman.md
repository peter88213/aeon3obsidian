---
date: 1933-02-07
time: 1933-02-07T14:30:00
---


- **When** : Tuesday 7 March 1933 14:30
- **Lasts** : 10 minutes

- **Participant** : [[Hercule Poirot]]
- **Participant** : [[Cyrus Hardman]]


- [[Hardman reveals he had taken a job protecting Ratchett, and so kept watch all night. He corroborates the Conductor’s story]]
- [[Hardman volunteers that he knew MacQueen and had worked with his father]]
- [[Hardman claims he is a traveling salesman, then comes clean and claims to be a private detective]]
- [[When offered, Hardman opts for a cigarette rather than a tobacco pipe]]
