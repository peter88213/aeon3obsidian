- Participant: [[Poirot]]

- Clue: [[French reply from door]]

1933-02-07

11:10

20 minutes