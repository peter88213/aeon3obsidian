- Participant: [[Poirot]]

- Witness: [[M. Bouc]]