---
date: 1933-02-07
time: 1933-02-07T20:03:00
---


- **When** : Tuesday 7 March 1933 20:03


- **Witness** : [[Count Andrenyi]]
- **Witness** : [[The Conductor]]
- **Witness** : [[Mary Debenham]]
- **Witness** : [[Greta Ohlsson]]
- **Clue** : [[Open Window]]
- **Clue** : [[No Footprints]]
- **Witness** : [[Antonio Foscarelli]]
- **Witness** : [[Mrs Hubbard]]
- **Relates to** : [[Poirot’s Decoy Theory]]
- **Witness** : [[Cyrus Hardman]]
- **Clue** : [[Fake conductor]]
- **Witness** : [[Princess Dragonmiroff]]
- **Witness** : [[M. Bouc]]
- **Witness** : [[Hector MacQueen]]
- **Witness** : [[Hildegarde Schmidt]]
- **Witness** : [[Colonel Arbuthnot]]
- **Witness** : [[Dr. Constantine]]
- **Witness** : [[The Valet]]
- **Clue** : [[Intruder in Mrs Hubbard’s apartment]]
- **Witness** : [[Countess Andrenyi]]
- **Participant** : [[Hercule Poirot]]
