- Participant: [[Poirot]]

- Witness: [[Foscarelli]]

- Witness: [[Arbuthnot]]

- Witness: [[Count]]

- Witness: [[Countess]]

- Witness: [[Hardman]]

- Witness: [[Coroner]]

- Witness: [[Greta]]

- Witness: [[MacQueen]]

- Witness: [[Hildegarde]]

- Witness: [[M. Bouc]]

- Witness: [[Mary]]

- Witness: [[Hubbard]]

- Witness: [[Princess]]

- Witness: [[Conductor]]

- Witness: [[Valet]]

- Clue: [[Smashed Watch showing 1245]]

- Clue: [[French reply from door]]

1933-02-07

20:12

3 minutes