---
date: 1933-02-07
time: 1933-02-07T19:45:00
---


- **When** : Tuesday 7 March 1933 19:45


- **Witness** : [[M. Bouc]]
- **Clue** : [[Ratchett’s true identity]]
- **Participant** : [[Hercule Poirot]]
- **Participant** : [[Cyrus Hardman]]
- **Witness** : [[Dr. Constantine]]
