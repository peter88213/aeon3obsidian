---
date: 1933-02-07
time: 1933-02-07T01:35:00
---


- **When** : Tuesday 7 March 1933 01:35
- **Lasts** : 8 hours, 10 minutes

- **Participant** : [[Hercule Poirot]]
