- Participant: [[Poirot]]

- Witness: [[Foscarelli]]

- Witness: [[Arbuthnot]]

- Witness: [[Count]]

- Witness: [[Countess]]

- Witness: [[Hardman]]

- Witness: [[Coroner]]

- Witness: [[Greta]]

- Witness: [[MacQueen]]

- Witness: [[Hildegarde]]

- Witness: [[M. Bouc]]

- Witness: [[Mary]]

- Witness: [[Hubbard]]

- Witness: [[Princess]]

- Witness: [[Conductor]]

- Witness: [[Valet]]

- Clue: [[Ratchett’s true identity]]

1933-02-07

20:24

3 minutes