---
date: 1933-02-06
time: 1933-02-06T22:30:00
tags: 
  - Alibi
---


- **When** : Monday 6 March 1933 22:30


- **Status** : Corroborated


- **Testimony** : [[The Conductor's Testimony]]
- **Participant** : [[The Conductor]]
- **Testimony** : [[The Valet's Testimony]]
- **Participant** : [[The Valet]]
- **Participant** : [[Antonio Foscarelli]]
- **Testimony** : [[Antonio Foscarelli's Testimony]]
