- Participant: [[MacQueen]]

- Participant: [[Ratchett]]

- Murder Theory: [[True Crime]]

- Clue: [[Sleeping Drug]]

1933-02-06

22:00