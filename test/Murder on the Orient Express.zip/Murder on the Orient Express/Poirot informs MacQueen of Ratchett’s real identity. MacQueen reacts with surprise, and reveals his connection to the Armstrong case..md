- Participant: [[Poirot]]

- Participant: [[MacQueen]]

- Clue: [[Ratchett’s true identity]]