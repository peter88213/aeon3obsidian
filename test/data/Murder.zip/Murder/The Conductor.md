---
aliases: 
  - Conductor
---


---

The father of Daisy’s nurse maid

---



- **Real Name** : Pierre Michel
- **Nationality** : French
- **Gender** : Male
- **Motivation** : His daughter was a nursemaid for Daisy Armstrong, who committed suicide as a result of police suspicion following Daisy’s murder.
- **Characteristics** : Dependable and honourable, but not intelligent, according to Poirot.
