---
date: 1933-02-06
time: 1933-02-06T23:00:00
tags: 
  - Alibi
---


- **When** : Monday 6 March 1933 23:00


- **Status** : Corroborated


- **Testimony** : [[The Conductor's Testimony]]
- **Participant** : [[The Conductor]]
- **Participant** : [[Count Andrenyi]]
- **Testimony** : [[Count Andrenyi's Testimony]]
