- Testimony: [[Hildegarde Schmidt's Testimony]]

- Participant: [[Hildegarde]]

#No_Alibi

1933-02-07

01:15

405 minutes