- Testimony: [[Mrs Hubbard's Testimony]]

- Participant: [[Hubbard]]

#No_Alibi

1933-02-07

02:00

6 hours