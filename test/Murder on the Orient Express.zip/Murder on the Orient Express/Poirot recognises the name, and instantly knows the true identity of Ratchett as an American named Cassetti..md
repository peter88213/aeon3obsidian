A man responsible for the kidnap and murder of a little girl called Daisy Armstrong



- Participant: [[Poirot]]

- Clue: [[Ratchett’s true identity]]

- Clue: [[Burnt letter mentioning Daisy Armstrong]]

#Burnt_Paper

1933-02-07

11:58