- Participant: [[Poirot]]

1933-02-07

01:35

8 hours, 10 minutes