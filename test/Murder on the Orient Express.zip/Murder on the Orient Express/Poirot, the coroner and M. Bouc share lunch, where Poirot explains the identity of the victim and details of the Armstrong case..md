- Participant: [[Poirot]]

- See also: [[Central Crime The Murder of Daisy Armstrong]]

- Relates to: [[Nursemaid]]

1933-02-07

12:00

1 hours, 10 minutes