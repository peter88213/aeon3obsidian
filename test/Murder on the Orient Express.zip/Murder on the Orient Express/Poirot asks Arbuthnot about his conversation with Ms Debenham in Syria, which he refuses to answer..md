- Participant: [[Poirot]]

- Participant: [[Arbuthnot]]

- Witness: [[M. Bouc]]

- Witness: [[Coroner]]

- Clue: [[Overheard “When it’s all over]]

1933-02-07

19:20

3 minutes