---
date: 1933-02-07
time: 1933-02-07T16:20:00
---


- **When** : Tuesday 7 March 1933 16:20
- **Lasts** : 2 hours

- **Participant** : [[Dr. Constantine]]
- **Participant** : [[Hercule Poirot]]


- [[Poirot believes the threatening letters were a decoy intended for police, and not Ratchett.]]
- [[Poirot suggests if the stopped watch was altered, it must be significant, and they should look at who has an alibi only for that time]]
- [[Poirot suggests the original plan was likely to make it appear the killer had left the train, but the blizzard had prevented this.]]
- [[Poirot lists many unresolved questions]]
- [[Poirot notes that MacQueen was employed because Ratchett knew only English, yet he supposedly spoke French to the conductor]]
- [[Poirot concludes that Countess Andrenyi is really Helena Goldenberg, the aunt of the murder victim, and that Princess Dragomiroff would have knnown this and so must have lied previously.]]
- [[Poirot determines that Princess Dragomiroff’s first name must be Helena and her passport has been deliberately sabotaged.]]
- [[Poirot decides the handkerchief may also have been deliberately planted, and that it is not an indication of the Princess’s guilt, but that the Princess still obscured her passport in a panic.]]
- [[Poirot lists the suspects and alibis, and finds most are vouched for by at least one other passenger, and have no obvious motive or evidence.]]
