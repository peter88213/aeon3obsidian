- Testimony: [[The Valet's Testimony]]

- Witness: [[Conductor]]

- Participant: [[Ratchett]]

- Participant: [[Valet]]

1933-02-06

21:00

40 minutes