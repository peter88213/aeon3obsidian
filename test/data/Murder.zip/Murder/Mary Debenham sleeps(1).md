---
date: 1933-02-06
time: 1933-02-06T22:00:00
tags: 
  - Alibi
---


- **When** : Monday 6 March 1933 22:00


- **Status** : Corroborated


- **Testimony** : [[Mary Debenham's Testimony]]
- **Participant** : [[Mary Debenham]]
- **Witness** : [[Greta Ohlsson]]
