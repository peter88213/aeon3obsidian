---
aliases: 
  - Hildegarde
---


---

Lady’s maid working for Princess Dragomiroff.

---



- **Nationality** : German
- **Motivation** : The chef of the Armstrong household at the time of Daisy’s kidnapping
