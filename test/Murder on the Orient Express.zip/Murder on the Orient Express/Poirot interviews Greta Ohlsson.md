- Participant: [[Poirot]]

- Participant: [[Greta]]

[[Greta Ohlsson confirms Mrs Hubbards recollections]]

[[Greta denies having ever been to America]]

[[Greta confirms that Mary Debenham never left the carriage they shared]]

1933-02-07

13:40

10 minutes