- Testimony: [[The Valet's Testimony]]

- Participant: [[Valet]]

1933-02-06

21:40

50 minutes