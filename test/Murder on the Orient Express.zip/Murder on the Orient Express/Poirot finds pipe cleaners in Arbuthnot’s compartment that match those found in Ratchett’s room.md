- Clue: [[Tobacco Pipe Cleaners]]

- Participant: [[Poirot]]

- Witness: [[Arbuthnot]]