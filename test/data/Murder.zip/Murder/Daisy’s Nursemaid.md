---
aliases: 
  - Nursemaid
---


---

Committed suicide following Daisy Armstrong’s murder, when police suspicion turned to her.

---



- **Gender** : Female


- **Nurse** : [[Daisy Armstrong]]
- **Parent** : [[The Conductor]]
