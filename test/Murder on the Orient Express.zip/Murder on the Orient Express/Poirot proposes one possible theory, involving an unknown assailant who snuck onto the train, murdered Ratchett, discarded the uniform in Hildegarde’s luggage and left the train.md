- Participant: [[Poirot]]

- Witness: [[Foscarelli]]

- Witness: [[Arbuthnot]]

- Witness: [[Count]]

- Witness: [[Countess]]

- Witness: [[Hardman]]

- Witness: [[Coroner]]

- Witness: [[Greta]]

- Witness: [[MacQueen]]

- Witness: [[Hildegarde]]

- Witness: [[M. Bouc]]

- Witness: [[Mary]]

- Witness: [[Hubbard]]

- Witness: [[Princess]]

- Witness: [[Conductor]]

- Witness: [[Valet]]

- Clue: [[No Footprints]]

- Clue: [[Open Window]]

- Clue: [[Fake conductor]]

- Clue: [[Intruder in Mrs Hubbard’s apartment]]

- Relates to: [[Poirot’s Decoy Theory]]

1933-02-07

20:03

3 minutes