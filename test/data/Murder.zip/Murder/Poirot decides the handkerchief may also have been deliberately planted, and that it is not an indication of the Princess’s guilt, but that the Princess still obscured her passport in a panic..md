




- **Participant** : [[Dr. Constantine]]
- **Participant** : [[Hercule Poirot]]
- **Clue** : [[Handkerchief with “H” monogram]]
- **Participant** : [[M. Bouc]]
