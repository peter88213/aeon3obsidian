Alibi from midnight to 2am (substantiated by MacQueen and the conductor)

- Participant: [[Hardman]]

- Testimony: [[Cyrus Hardman's Testimony]]

#Partial_Alibi

1933-02-06

22:00

10 hours