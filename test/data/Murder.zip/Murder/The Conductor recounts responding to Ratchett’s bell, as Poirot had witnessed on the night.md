




- **See also** : [[After multiple passengers hear a groan, the Conductor answers Ratchett’s ringing bell]]
- **Participant** : [[Hercule Poirot]]
- **Clue** : [[French reply from door]]
- **Participant** : [[The Conductor]]
