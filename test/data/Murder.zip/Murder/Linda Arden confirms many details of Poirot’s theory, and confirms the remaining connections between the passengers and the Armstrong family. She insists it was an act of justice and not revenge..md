---
date: 1933-02-07
time: 1933-02-07T20:24:00
---


- **When** : Tuesday 7 March 1933 20:24


- **Witness** : [[Greta Ohlsson]]
- **Witness** : [[Dr. Constantine]]
- **Witness** : [[Hector MacQueen]]
- **Witness** : [[Princess Dragonmiroff]]
- **Witness** : [[M. Bouc]]
- **Clue** : [[Ratchett’s true identity]]
- **Witness** : [[Countess Andrenyi]]
- **Witness** : [[Mrs Hubbard]]
- **Participant** : [[Hercule Poirot]]
- **Witness** : [[Colonel Arbuthnot]]
- **Witness** : [[Hildegarde Schmidt]]
- **Witness** : [[The Conductor]]
- **Witness** : [[The Valet]]
- **Witness** : [[Count Andrenyi]]
- **Witness** : [[Mary Debenham]]
- **Witness** : [[Cyrus Hardman]]
- **Witness** : [[Antonio Foscarelli]]
