- Participant: [[Countess]]

- Witness: [[Count]]

- Testimony: [[Countess Andrenyi's Testimony]]

- Testimony: [[Count Andrenyi's Testimony]]

#Alibi

1933-02-06

23:00

9 hours