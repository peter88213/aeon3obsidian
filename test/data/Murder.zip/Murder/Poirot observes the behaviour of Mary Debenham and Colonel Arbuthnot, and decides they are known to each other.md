




- **Participant** : [[Colonel Arbuthnot]]
- **Participant** : [[Hercule Poirot]]
- **Participant** : [[Mary Debenham]]
