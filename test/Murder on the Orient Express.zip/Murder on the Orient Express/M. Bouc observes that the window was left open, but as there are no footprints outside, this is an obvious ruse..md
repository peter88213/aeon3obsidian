Given the train has been stuck in a snowdrift since then and has not moved position, the lack of footprints rules out the window as an escape route.

- Participant: [[Poirot]]

- Participant: [[M. Bouc]]

- Participant: [[Coroner]]

- Clue: [[Open Window]]

- Clue: [[No Footprints]]

1933-02-07

10:45

25 minutes