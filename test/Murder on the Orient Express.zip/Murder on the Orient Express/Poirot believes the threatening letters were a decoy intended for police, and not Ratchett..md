- Clue: [[Threatening letters]]

- Participant: [[Poirot]]

- Participant: [[M. Bouc]]

- Participant: [[Coroner]]