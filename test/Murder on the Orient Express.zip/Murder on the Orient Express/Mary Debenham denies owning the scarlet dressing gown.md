- Clue: [[Scarlett Dressing Gown]]

- Participant: [[Mary]]

- Participant: [[Poirot]]