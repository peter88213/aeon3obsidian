---
date: 1933-02-07
time: 1933-02-07T00:18:00
tags: 
  - Imposter_Conductor_s_uniform
---


---

She lied about the time to try to shield the Princess

---

- **When** : Tuesday 7 March 1933 0:18


- **Status** : Known Lie


- **Participant** : [[Unknown Intruder]]
- **Murder Theory** : [[Poirot’s Decoy Theory]]
- **Participant** : [[Hildegarde Schmidt]]
