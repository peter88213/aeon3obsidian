- Testimony: [[The Valet's Testimony]]

- Participant: [[Conductor]]

- Participant: [[Foscarelli]]

- Participant: [[Valet]]

- Testimony: [[The Conductor's Testimony]]

- Testimony: [[Antonio Foscarelli's Testimony]]

#Alibi

1933-02-06

22:30