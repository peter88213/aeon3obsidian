---
date: 1933-02-06
time: 1933-02-06T22:00:00
---


- **When** : Monday 6 March 1933 22:00


- **Status** : Established Fact


- **Participant** : [[Hector MacQueen]]
- **Clue** : [[Sleeping Drug]]
- **Murder Theory** : [[The Real Crime]]
- **Participant** : [[Mr Ratchett]]
