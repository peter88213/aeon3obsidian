---
date: 1912-02-11
time: 1912-02-11T00:00:00
aliases: 
  - Countess
---


---

Sonia Armstrong’s sister. With her strongest connection to Daisy Armstrong, she does not actively participate in the murder.

---

- **When** : Sunday 11 March 1912 0:00


- **Nationality** : Hungarian
- **Real Name** : Helena Goldenberg
- **Motivation** : She is the sister to Sonia Armstrong, and therefore Daisy Armstrong’s niece.


- **Spouse** : [[Count Andrenyi]]
- **Sibling** : [[Sonia Armstrong]]
