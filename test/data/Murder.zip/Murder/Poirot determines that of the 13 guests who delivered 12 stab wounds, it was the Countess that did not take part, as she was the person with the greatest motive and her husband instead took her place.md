---
date: 1933-02-07
time: 1933-02-07T20:18:00
---


- **When** : Tuesday 7 March 1933 20:18
- **Lasts** : 3 minutes

- **Witness** : [[The Valet]]
- **Witness** : [[Dr. Constantine]]
- **Witness** : [[Countess Andrenyi]]
- **Clue** : [[Stab wounds]]
- **Witness** : [[Antonio Foscarelli]]
- **Witness** : [[Mrs Hubbard]]
- **Witness** : [[M. Bouc]]
- **Witness** : [[Greta Ohlsson]]
- **Witness** : [[Mary Debenham]]
- **Witness** : [[Cyrus Hardman]]
- **Witness** : [[Hector MacQueen]]
- **Witness** : [[The Conductor]]
- **Witness** : [[Colonel Arbuthnot]]
- **Participant** : [[Hercule Poirot]]
- **Witness** : [[Hildegarde Schmidt]]
- **Witness** : [[Princess Dragonmiroff]]
- **Witness** : [[Count Andrenyi]]
