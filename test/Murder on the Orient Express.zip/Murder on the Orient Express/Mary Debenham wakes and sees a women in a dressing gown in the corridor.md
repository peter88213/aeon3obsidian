- Participant: [[Mary]]

- Testimony: [[Mary Debenham's Testimony]]

- Clue: [[Scarlett Dressing Gown]]

#No_Alibi

#Clue

#Imposter_in_Kimono

1933-02-07

04:59