




- **Witness** : [[Hercule Poirot]]
- **Participant** : [[Mary Debenham]]
- **Participant** : [[Colonel Arbuthnot]]
