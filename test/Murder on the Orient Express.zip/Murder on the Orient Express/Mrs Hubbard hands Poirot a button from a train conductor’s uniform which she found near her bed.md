- Participant: [[Poirot]]

- Clue: [[Fake conductor]]