




- **Witness** : [[M. Bouc]]
- **Participant** : [[Hercule Poirot]]
