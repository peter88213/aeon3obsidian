- Participant: [[Poirot]]

- Witness: [[Foscarelli]]

- Witness: [[Arbuthnot]]

- Witness: [[Count]]

- Witness: [[Countess]]

- Witness: [[Hardman]]

- Witness: [[Greta]]

- Witness: [[MacQueen]]

- Witness: [[Hildegarde]]

- Witness: [[Mary]]

- Witness: [[Hubbard]]

- Witness: [[Princess]]

- Witness: [[Conductor]]

- Witness: [[Valet]]

- Participant: [[M. Bouc]]

- Participant: [[Coroner]]

1933-02-07

20:06

3 minutes