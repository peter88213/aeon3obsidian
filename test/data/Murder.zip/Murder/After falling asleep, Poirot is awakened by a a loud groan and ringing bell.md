---
date: 1933-02-07
time: 1933-02-07T00:37:00
---


---

He also notices the train has stopped.

---

- **When** : Tuesday 7 March 1933 0:37


- **Status** : Established Fact


- **Participant** : [[Hercule Poirot]]
