- Clue: [[Fake conductor]]

- Participant: [[Poirot]]

- Witness: [[M. Bouc]]