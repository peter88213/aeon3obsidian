- Participant: [[Mary]]

- Witness: [[Greta]]

- Testimony: [[Mary Debenham's Testimony]]

#Alibi

1933-02-06

22:00

7 hours