- Participant: [[Poirot]]

- Clue: [[Handkerchief with “H” monogram]]

#Clue

#Hankerchief

1933-02-07

11:37