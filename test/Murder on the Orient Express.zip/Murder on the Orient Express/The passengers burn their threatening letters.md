- Participant: [[Hardman]]

- Participant: [[MacQueen]]

- Participant: [[Mary]]

- Participant: [[Conductor]]

- Participant: [[Foscarelli]]

- Participant: [[Valet]]

- Participant: [[Greta]]

- Participant: [[Princess]]

- Participant: [[Arbuthnot]]

- Participant: [[Hubbard]]

- Participant: [[Count]]

- Participant: [[Hildegarde]]

- Murder Theory: [[True Crime]]

- Clue: [[Threatening letters]]

#Burnt_Paper

1933-02-07

02:00