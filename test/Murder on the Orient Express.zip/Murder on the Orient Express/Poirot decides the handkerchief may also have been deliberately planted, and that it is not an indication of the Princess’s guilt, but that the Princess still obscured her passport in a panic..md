- Clue: [[Handkerchief with “H” monogram]]

- Participant: [[Poirot]]

- Participant: [[M. Bouc]]

- Participant: [[Coroner]]