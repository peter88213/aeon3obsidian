---
date: 1933-02-06
time: 1933-02-06T22:55:00
tags: 
  - Alibi
---


- **When** : Monday 6 March 1933 22:55


- **Status** : Corroborated


- **Testimony** : [[Greta Ohlsson's Testimony]]
- **Participant** : [[Greta Ohlsson]]
- **Witness** : [[Mary Debenham]]
