- Participant: [[MacQueen]]

- Participant: [[Ratchett]]

- Testimony: [[Hector MacQueen's Testimony]]

- Testimony: [[The Conductor's Testimony]]

1933-02-06

21:40

20 minutes