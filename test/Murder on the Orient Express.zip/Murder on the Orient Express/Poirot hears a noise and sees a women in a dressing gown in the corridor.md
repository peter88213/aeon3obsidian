- Witness: [[MacQueen]]

- Participant: [[Poirot]]

- Witness: [[Conductor]]

- Witness: [[Arbuthnot]]

- Clue: [[Scarlett Dressing Gown]]

#Clue

#Imposter_in_Kimono

1933-02-07

01:35