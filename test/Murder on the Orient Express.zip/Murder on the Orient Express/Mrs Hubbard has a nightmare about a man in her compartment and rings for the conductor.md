- Participant: [[Conductor]]

- Participant: [[Hubbard]]

- Participant: [[Intruder]]

- Murder Theory: [[Poirot’s Decoy Theory]]

1933-02-07

01:17

8 minutes