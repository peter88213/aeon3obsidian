- See also: [[The Valet lies awake with a toothache]]

- See also: [[Antonio Foscarelli reads in his compartment, which is confirmed by The Valet who shared his room]]

- Participant: [[Foscarelli]]

- Participant: [[Poirot]]