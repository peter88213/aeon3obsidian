- Participant: [[Poirot]]

- Witness: [[M. Bouc]]

- Witness: [[Coroner]]

- Clue: [[Ratchett’s true identity]]

- Participant: [[Hardman]]

1933-02-07

19:45