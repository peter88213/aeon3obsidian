- Participant: [[Poirot]]

- Participant: [[Hildegarde]]

[[Hildegarde claims her dressing gown is dark blue]]

[[Hildegarde participates in a line up, and claims none of the three conductors was the person she saw when]]

[[Hildegarde corroborates Mary Debenham’s version of events.]]

[[Hildegarde claims not to own the handkerchief]]

[[Hildegarde claims to have seen a conductor leave an apartment and ignore a ringing bell]]

[[Hildegarde reacts to being asked about a woman in a scarlett dressing gown, but denies seeing one]]

1933-02-07

15:00

10 minutes