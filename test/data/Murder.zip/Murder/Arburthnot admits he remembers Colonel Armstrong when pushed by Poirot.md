




- **Clue** : [[Ratchett’s true identity]]
- **Participant** : [[Hercule Poirot]]
- **Testimony** : [[Hector MacQueen's Testimony]]
- **Participant** : [[Colonel Arbuthnot]]
