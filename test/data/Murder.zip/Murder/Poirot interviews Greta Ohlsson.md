---
date: 1933-02-07
time: 1933-02-07T13:40:00
---


- **When** : Tuesday 7 March 1933 13:40


- **Participant** : [[Hercule Poirot]]
- **Participant** : [[Greta Ohlsson]]


- [[Greta Ohlsson confirms Mrs Hubbards recollections]]
- [[Greta denies having ever been to America]]
- [[Greta confirms that Mary Debenham never left the carriage they shared]]
