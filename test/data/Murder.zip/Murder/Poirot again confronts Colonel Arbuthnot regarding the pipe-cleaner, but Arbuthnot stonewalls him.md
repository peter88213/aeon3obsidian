---
date: 1933-02-07
time: 1933-02-07T19:25:00
---


- **When** : Tuesday 7 March 1933 19:25


- **Participant** : [[Colonel Arbuthnot]]
- **Witness** : [[M. Bouc]]
- **Participant** : [[Hercule Poirot]]
- **Witness** : [[Dr. Constantine]]
- **Clue** : [[Tobacco Pipe Cleaners]]
