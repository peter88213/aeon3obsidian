- Participant: [[Ratchett]]

- Participant: [[Greta]]

- Testimony: [[Greta Ohlsson's Testimony]]

- Witness: [[Hubbard]]

- Testimony: [[Mrs Hubbard's Testimony]]

1933-02-06

22:40