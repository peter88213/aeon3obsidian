- Witness: [[Mary]]

- Participant: [[Greta]]

- Testimony: [[Greta Ohlsson's Testimony]]

#Alibi

1933-02-06

22:55

545 minutes