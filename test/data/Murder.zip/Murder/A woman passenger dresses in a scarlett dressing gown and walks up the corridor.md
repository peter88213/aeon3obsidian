---
date: 1933-02-07
time: 1933-02-07T01:35:00
tags: 
  - Imposter_in_Kimono
---


- **When** : Tuesday 7 March 1933 1:35


- **Status** : Established Fact


- **Witness** : [[Hercule Poirot]]
- **Murder Theory** : [[The Real Crime]]
- **Clue** : [[Scarlett Dressing Gown]]
- **Clue** : [[Fake conductor]]
