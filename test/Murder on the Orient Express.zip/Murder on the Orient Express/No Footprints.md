No Footprints

- Relates to: [[Open Window]]