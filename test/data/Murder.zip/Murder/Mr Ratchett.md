---
date: 1868-02-20
time: 1868-02-20T00:00:00
aliases: 
  - Ratchett
---


---

Real name Cassetti, kidnapped and murdered Daisy Armstrong.

---

- **When** : Thursday 20 March 1868 00:00
- **Lasts** : 23728 days

- **Nationality** : American
- **Real Name** : Cassetti
- **Gender** : Male
- **Characteristics** : Older man in his 60s, gives off a sinister impression to Poirot.
- **Motivation** : Hiding his true identity, the American Cassetti, who escaped conviction for the murder of Daisy Armstrong.
  Appeals to Poirot to investigate a possible attempt on his life, which Poriot declines.


- **Relates to** : [[Central Crime The Murder of Daisy Armstrong]]
