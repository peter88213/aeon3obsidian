---
date: 1933-02-06
time: 1933-02-06T22:39:00
---


---

This was the last time Ratchett was seen alive

---

- **When** : Monday 6 March 1933 22:39


- **Participant** : [[Mr Ratchett]]
- **Participant** : [[Greta Ohlsson]]
- **Witness** : [[Mrs Hubbard]]
