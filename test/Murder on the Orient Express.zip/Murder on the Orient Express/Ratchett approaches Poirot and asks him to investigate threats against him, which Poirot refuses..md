- Participant: [[Poirot]]

- Participant: [[Ratchett]]