- Participant: [[Poirot]]

- Participant: [[Greta]]