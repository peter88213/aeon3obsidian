




- **Participant** : [[Hercule Poirot]]
- **Witness** : [[M. Bouc]]
- **Clue** : [[Bloody knife]]
