---
date: 1933-02-07
time: 1933-02-07T14:40:00
---


- **When** : Tuesday 7 March 1933 14:40


- **Participant** : [[Hercule Poirot]]
- **Participant** : [[Antonio Foscarelli]]


- [[Foscarelli confirms the story of the Valet, that they both remained in their compartment all night]]
