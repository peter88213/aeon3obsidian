- Participant: [[Poirot]]

- Participant: [[M. Bouc]]

1933-02-07

10:45

5 minutes