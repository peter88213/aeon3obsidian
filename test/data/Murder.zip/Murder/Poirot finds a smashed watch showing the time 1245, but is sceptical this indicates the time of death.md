---
date: 1933-02-07
time: 1933-02-07T11:45:00
tags: 
  - Clue
---


---

The hands point to 1:15

---

- **When** : Tuesday 7 March 1933 11:45


- **Status** : Established Fact


- **Participant** : [[Hercule Poirot]]
- **Clue** : [[Smashed Watch showing 1245]]
