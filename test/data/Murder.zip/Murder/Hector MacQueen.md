---
date: 1903-02-07
time: 1903-02-07T00:00:00
aliases: 
  - MacQueen
---


---

Ratchett's personal secretary, his father was the prosecutor in the failed case.

---

- **When** : Saturday 7 March 1903 00:00


- **Nationality** : American
- **Gender** : Male
- **Motivation** : Took a job with Ratchett to assist in his travels to aide with various languages of Europe.
  Hector’s father unsuccessfully prosecuted Ratchett for Daisy’s death, so he has a personal grudge against Ratchett.
- **Characteristics** : Fluent in French.


- **Relates to** : [[Central Crime The Murder of Daisy Armstrong]]
