Leaves behind murder weapon and button from cloak



- Witness: [[Hubbard]]

- Participant: [[Intruder]]

- Murder Theory: [[Poirot’s Decoy Theory]]

1933-02-07

00:20