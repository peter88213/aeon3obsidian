---
date: 1933-02-07
time: 1933-02-07T01:17:00
---


---

She lies about hearing a man in her compartment



---

- **When** : Tuesday 7 March 1933 1:17


- **Status** : Established Fact


- **Witness** : [[Hercule Poirot]]
- **Participant** : [[The Conductor]]
- **Participant** : [[Mrs Hubbard]]
- **Clue** : [[Intruder in Mrs Hubbard’s apartment]]
- **Murder Theory** : [[The Real Crime]]
- **Clue** : [[Fake conductor]]
