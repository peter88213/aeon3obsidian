




- **See also** : [[Antonio Foscarelli reads in his compartment]]
- **Participant** : [[Antonio Foscarelli]]
- **See also** : [[The Valet lies awake with a toothache]]
- **Participant** : [[Hercule Poirot]]
