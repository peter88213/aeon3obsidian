---
aliases: 
  - Poirot
---




- **Nationality** : Belgian
- **Gender** : Male
- **Motivation** : Renowned detective stumbles onto a murder, and feels it necessary to solve it to maintain his reputation.
  However, upon discovering the true nature of the crime, his motivation shifts to providing a plausible cover-up to allow the true murderers to escape punishment.
- **Characteristics** : Short, bald man devoted to fashion and tidiness.
  Uses innocent appearance to lull unsuspecting suspects to talk openly around him.
