- Relates to: [[Scarlett Dressing Gown]]

- Participant: [[Poirot]]

- Participant: [[Coroner]]

- Participant: [[M. Bouc]]