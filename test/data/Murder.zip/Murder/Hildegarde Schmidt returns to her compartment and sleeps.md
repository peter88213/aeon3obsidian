---
date: 1933-02-07
time: 1933-02-07T01:15:00
tags: 
  - No_Alibi
---


- **When** : Tuesday 7 March 1933 1:15


- **Status** : Uncorroborated


- **Participant** : [[Hildegarde Schmidt]]
- **Testimony** : [[Hildegarde Schmidt's Testimony]]
