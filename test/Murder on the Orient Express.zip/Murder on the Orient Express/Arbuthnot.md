Arbuthnot

A friend of Daisy Armstrong’s father.

- Friend: [[Colonel Armstrong]]

1865-02-21

00:00