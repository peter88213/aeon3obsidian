




- **Clue** : [[Fake conductor]]
- **Participant** : [[Hercule Poirot]]
