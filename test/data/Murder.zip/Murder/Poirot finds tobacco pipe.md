---
date: 1933-02-07
time: 1933-02-07T11:39:00
tags: 
  - Clue
  - Pipe
---


---

Matches Colonel Arthbutnots

---

- **When** : Tuesday 7 March 1933 11:39


- **Status** : Established Fact


- **Clue** : [[Tobacco Pipe Cleaners]]
- **Participant** : [[Hercule Poirot]]
