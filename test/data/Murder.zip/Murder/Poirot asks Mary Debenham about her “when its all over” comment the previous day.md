




- **Participant** : [[Mary Debenham]]
- **Participant** : [[Hercule Poirot]]
- **Clue** : [[Overheard “When it’s all over]]
