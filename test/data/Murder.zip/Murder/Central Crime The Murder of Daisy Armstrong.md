


---

Mr Ratchett, an American with the real name Cassetti, murdered Daisy Armstrong for money, but escaped punishment after bribing people involved in the trial.

The central characters to the story are seeking to punish him for his crime.

---



- [[Young girl Daisy Armstrong is kidnapped and murdered]]
- [[The Armstrong family and those connected are outraged by the miscarriage of justice, and wish to seek justice on their own.]]
- [[The American Cassetti is obviously guilty and prosecuted for the crime, but escaped punishment after bribing people involved in the trial.]]
