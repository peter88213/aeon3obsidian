- Clue: [[Handkerchief with “H” monogram]]

- Clue: [[Ratchett’s true identity]]

- Participant: [[Poirot]]

- Participant: [[M. Bouc]]

- Participant: [[Coroner]]