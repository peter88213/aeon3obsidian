- Participant: [[Hildegarde]]

- Participant: [[Poirot]]

- Participant: [[Coroner]]

- Clue: [[Fake conductor]]