




- **Witness** : [[Countess Andrenyi]]
- **Participant** : [[Hercule Poirot]]
- **Witness** : [[Count Andrenyi]]
