---
date: 1933-02-07
time: 1933-02-07T20:21:00
---


- **When** : Tuesday 7 March 1933 20:21
- **Lasts** : 3 minutes

- **Witness** : [[Hildegarde Schmidt]]
- **Witness** : [[Countess Andrenyi]]
- **Witness** : [[Greta Ohlsson]]
- **Witness** : [[Mary Debenham]]
- **Witness** : [[Dr. Constantine]]
- **Witness** : [[Colonel Arbuthnot]]
- **Witness** : [[Count Andrenyi]]
- **Witness** : [[M. Bouc]]
- **Witness** : [[The Valet]]
- **Witness** : [[The Conductor]]
- **Witness** : [[Hector MacQueen]]
- **Witness** : [[Princess Dragonmiroff]]
- **Witness** : [[Cyrus Hardman]]
- **Witness** : [[Mrs Hubbard]]
- **Witness** : [[Antonio Foscarelli]]
- **Participant** : [[Hercule Poirot]]
