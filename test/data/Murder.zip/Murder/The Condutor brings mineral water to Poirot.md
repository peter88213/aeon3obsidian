---
date: 1933-02-07
time: 1933-02-07T01:25:00
tags: 
  - Alibi
---


- **When** : Tuesday 7 March 1933 1:25


- **Status** : Established Fact


- **Testimony** : [[The Conductor's Testimony]]
- **Participant** : [[Hercule Poirot]]
- **Witness** : [[Cyrus Hardman]]
- **Participant** : [[The Conductor]]
