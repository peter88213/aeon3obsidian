---
date: 1933-02-07
time: 1933-02-07T00:30:00
tags: 
  - Clue
  - Train_Movement
---


---

After this time it was impossible for anyone to leave the train



---

- **When** : Tuesday 7 March 1933 00:30
- **Lasts** : 9 hours, 15 minutes

- **Status** : Established Fact


- **Clue** : [[Open Window]]
- **Story Arc** : [[Train Movements]]
- **Clue** : [[No Footprints]]
