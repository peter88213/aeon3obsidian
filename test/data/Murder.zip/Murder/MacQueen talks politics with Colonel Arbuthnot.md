---
date: 1933-02-06
time: 1933-02-06T22:00:00
tags: 
  - Alibi
---


- **When** : Monday 6 March 1933 22:00
- **Lasts** : 3 hours, 45 minutes

- **Status** : Corroborated


- **Participant** : [[Hector MacQueen]]
- **Testimony** : [[Hector MacQueen's Testimony]]
- **Participant** : [[Colonel Arbuthnot]]
- **Testimony** : [[Colonel Arbuthnot's Testimony]]
