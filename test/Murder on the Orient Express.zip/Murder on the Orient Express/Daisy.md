Daisy

- Parent: [[Sonia Armstrong]]

- Parent: [[Colonel Armstrong]]

- Relates to: [[Central Crime The Murder of Daisy Armstrong]]