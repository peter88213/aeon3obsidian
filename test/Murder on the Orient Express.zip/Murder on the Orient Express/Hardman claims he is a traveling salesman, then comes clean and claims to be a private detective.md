- Participant: [[Poirot]]

- Participant: [[Hardman]]