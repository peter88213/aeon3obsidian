- Participant: [[Poirot]]

- Participant: [[Coroner]]

- Participant: [[M. Bouc]]