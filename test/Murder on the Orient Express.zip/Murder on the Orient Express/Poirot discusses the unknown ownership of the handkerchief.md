- Relates to: [[Handkerchief with “H” monogram]]

- Participant: [[Poirot]]

- Participant: [[Coroner]]

- Participant: [[M. Bouc]]