---
aliases: 
  - Coroner
---




- **Nationality** : Greek
- **Gender** : Male
- **Motivation** : Asked to examine the body by Poirot and M Bouc.
