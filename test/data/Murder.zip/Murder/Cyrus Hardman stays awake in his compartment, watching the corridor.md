---
date: 1933-02-06
time: 1933-02-06T22:00:00
tags: 
  - Partial_Alibi
---


---

Alibi from midnight to 2am (substantiated by MacQueen and the conductor)

---

- **When** : Monday 6 March 1933 22:00


- **Status** : Corroborated


- **Participant** : [[Cyrus Hardman]]
- **Testimony** : [[Cyrus Hardman's Testimony]]
