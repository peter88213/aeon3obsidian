---
date: 1933-02-07
time: 1933-02-07T01:35:00
---


- **When** : Tuesday 7 March 1933 1:35


- **Participant** : [[Hercule Poirot]]
