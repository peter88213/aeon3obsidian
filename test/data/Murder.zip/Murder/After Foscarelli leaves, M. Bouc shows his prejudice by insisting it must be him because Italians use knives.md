




- **Participant** : [[Hercule Poirot]]
- **Participant** : [[M. Bouc]]
