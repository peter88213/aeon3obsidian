


---

Poirot establishes the connection between each passenger and the murder victim, and establishes the motive.

He surmises that they were all involved in the plot to kill Ratchett, and that they all took park in the stabbing, so that no single person could be blamed for the murder.

---

