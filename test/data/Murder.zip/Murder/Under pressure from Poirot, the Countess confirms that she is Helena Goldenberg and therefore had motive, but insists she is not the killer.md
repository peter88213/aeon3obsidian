---
date: 1933-02-07
time: 1933-02-07T19:10:00
---


- **When** : Tuesday 7 March 1933 19:10
- **Lasts** : 2 minutes

- **Participant** : [[Hercule Poirot]]
- **Witness** : [[Count Andrenyi]]
- **Participant** : [[Countess Andrenyi]]
- **Clue** : [[Ratchett’s true identity]]
- **Witness** : [[M. Bouc]]
