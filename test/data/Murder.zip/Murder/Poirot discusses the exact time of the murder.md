




- **Participant** : [[Dr. Constantine]]
- **Participant** : [[M. Bouc]]
- **Participant** : [[Hercule Poirot]]
- **Relates to** : [[Smashed Watch showing 1245]]
