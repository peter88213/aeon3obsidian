---
date: 1933-02-07
time: 1933-02-07T04:00:00
tags: 
  - No_Alibi
---


- **When** : Tuesday 7 March 1933 4:00


- **Status** : Uncorroborated


- **Witness** : [[Antonio Foscarelli]]
- **Participant** : [[The Valet]]
- **Testimony** : [[The Valet's Testimony]]
