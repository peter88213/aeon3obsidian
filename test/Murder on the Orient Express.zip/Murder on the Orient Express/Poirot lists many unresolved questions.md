- Participant: [[Poirot]]

- Participant: [[Coroner]]

- Participant: [[M. Bouc]]

[[Poirot discusses the ownership of the dressing gown]]

[[Dr Constantine suggests there may be multiple murderers acting independently, based on the evidence of the wounds]]

[[Poirot discusses his belief the pipe cleaner is a fake clue]]

[[Poirot discusses the unknown ownership of the handkerchief]]

[[Poirot discusses the exact time of the murder]]