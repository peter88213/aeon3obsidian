---
date: 1900-02-13
time: 1900-02-13T00:00:00
aliases: 
  - Hardman
---


---

The lover of Daisy Armstrong’s nurse maid

---

- **When** : Tuesday 13 March 1900 00:00


- **Motivation** : Introduces himself as a travelling salesman, and then private investigator, to hide his connection to the crime.
  The lover of Daisy Armstrong’s nurse maid, who committed suicide as a result of police suspicion following Daisy’s murder.
- **Gender** : Male
- **Nationality** : American


- **Partner** : [[Daisy’s Nursemaid]]
