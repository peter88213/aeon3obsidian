---
date: 1908-02-12
time: 1908-02-12T00:00:00
aliases: 
  - Mary
---


---

Countess Andrenyi’s governess

---

- **When** : Wednesday 12 March 1908 00:00


- **Nationality** : British
- **Motivation** : Countess Andrenyi’s governess at the time Daisy Armstrong was kidnapped.


- **Associate** : [[Countess Andrenyi]]
