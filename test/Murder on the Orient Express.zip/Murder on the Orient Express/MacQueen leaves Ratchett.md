- Participant: [[MacQueen]]

- Witness: [[Conductor]]

- Participant: [[Ratchett]]

1933-02-06

22:00