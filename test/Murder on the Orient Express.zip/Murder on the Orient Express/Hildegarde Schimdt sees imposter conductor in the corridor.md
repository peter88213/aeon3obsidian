She lied about the time to try to shield the Princess

- Participant: [[Hildegarde]]

- Participant: [[Intruder]]

- Murder Theory: [[Poirot’s Decoy Theory]]

#Imposter_in_Conductor's_uniform

1933-02-07

00:18