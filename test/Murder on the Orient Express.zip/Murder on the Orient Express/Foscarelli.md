Foscarelli

Chauffer to the Armstrong household at the time of Daisy’s kidnapping.

- Associate: [[Colonel Armstrong]]