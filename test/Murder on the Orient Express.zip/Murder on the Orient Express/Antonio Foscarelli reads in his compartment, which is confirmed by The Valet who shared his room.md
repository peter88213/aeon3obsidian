- Participant: [[Foscarelli]]

- Witness: [[Valet]]

- Testimony: [[Antonio Foscarelli's Testimony]]

#Alibi

1933-02-06

22:30

330 minutes