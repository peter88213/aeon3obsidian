---
date: 1933-02-07
time: 1933-02-07T02:00:00
tags: 
  - No_Alibi
---


- **When** : Tuesday 7 March 1933 2:00


- **Status** : Uncorroborated


- **Participant** : [[Mrs Hubbard]]
- **Testimony** : [[Mrs Hubbard's Testimony]]
