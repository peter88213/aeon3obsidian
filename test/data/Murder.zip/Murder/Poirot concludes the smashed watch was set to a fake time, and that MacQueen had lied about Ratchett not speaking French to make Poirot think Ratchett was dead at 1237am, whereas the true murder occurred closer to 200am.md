---
date: 1933-02-07
time: 1933-02-07T20:12:00
---


- **When** : Tuesday 7 March 1933 20:12
- **Lasts** : 3 minutes

- **Witness** : [[Hector MacQueen]]
- **Witness** : [[Cyrus Hardman]]
- **Clue** : [[Smashed Watch showing 1245]]
- **Witness** : [[The Conductor]]
- **Witness** : [[Hildegarde Schmidt]]
- **Witness** : [[Count Andrenyi]]
- **Witness** : [[Dr. Constantine]]
- **Witness** : [[Greta Ohlsson]]
- **Witness** : [[Colonel Arbuthnot]]
- **Witness** : [[Princess Dragonmiroff]]
- **Participant** : [[Hercule Poirot]]
- **Witness** : [[Mrs Hubbard]]
- **Witness** : [[Antonio Foscarelli]]
- **Witness** : [[M. Bouc]]
- **Witness** : [[The Valet]]
- **Witness** : [[Countess Andrenyi]]
- **Witness** : [[Mary Debenham]]
- **Clue** : [[French reply from door]]
