- Clue: [[Scarlett Dressing Gown]]

- Participant: [[Poirot]]

- Participant: [[Hildegarde]]