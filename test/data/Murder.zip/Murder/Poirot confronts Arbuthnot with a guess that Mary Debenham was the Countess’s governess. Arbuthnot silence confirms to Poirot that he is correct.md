---
date: 1933-02-07
time: 1933-02-07T19:23:00
---


- **When** : Tuesday 7 March 1933 19:23
- **Lasts** : 2 minutes

- **Participant** : [[Colonel Arbuthnot]]
- **Participant** : [[Hercule Poirot]]
- **Clue** : [[Ratchett’s true identity]]
- **Witness** : [[Dr. Constantine]]
- **Witness** : [[M. Bouc]]
