- Relates to: [[Smashed Watch showing 1245]]

- Participant: [[Poirot]]

- Participant: [[Coroner]]

- Participant: [[M. Bouc]]