---
date: 1933-02-07
time: 1933-02-07T01:17:00
tags: 
  - Alibi
  - Clue
---


- **When** : Tuesday 7 March 1933 1:17


- **Status** : Corroborated


- **Testimony** : [[The Conductor's Testimony]]
- **Testimony** : [[Mrs Hubbard's Testimony]]
- **Witness** : [[Hercule Poirot]]
- **Participant** : [[The Conductor]]
- **Participant** : [[Mrs Hubbard]]
- **Relates to** : [[Intruder in Mrs Hubbard’s apartment]]
