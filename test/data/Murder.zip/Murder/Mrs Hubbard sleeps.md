---
date: 1933-02-06
time: 1933-02-06T22:40:00
tags: 
  - No_Alibi
---


- **When** : Monday 6 March 1933 22:40
- **Lasts** : 2 hours, 37 minutes

- **Status** : Uncorroborated


- **Testimony** : [[Mrs Hubbard's Testimony]]
- **Participant** : [[Mrs Hubbard]]
