---
date: 1861-02-22
time: 1861-02-22T00:00:00
aliases: 
  - Hubbard
---


---

Real name Linda Arden, she is Daisy Armstrong’s grandmother

---

- **When** : Friday 22 March 1861 0:00


- **Real Name** : Linda Arden
- **Nationality** : American
- **Motivation** : The grandmother of Daisy Armstrong
- **Characteristics** : "Distintively American”, according to fellow passengers.  
  Nosy, gossiping and arrogant.


- **Grandparent** : [[Daisy Armstrong]]
