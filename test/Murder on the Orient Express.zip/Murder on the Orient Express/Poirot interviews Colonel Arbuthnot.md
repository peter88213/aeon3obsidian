- Participant: [[Poirot]]

- Participant: [[Arbuthnot]]

- Testimony: [[Hector MacQueen's Testimony]]

[[Arbuthnot volunteers that he smokes a pipe]]

[[Arbuthnot confirms he was up late in discussion with MacQueen]]

[[Arburthnot admits he remembers Colonel Armstrong when pushed by Poirot.]]

1933-02-07

14:20

10 minutes