




- **Participant** : [[Hercule Poirot]]
- **Clue** : [[Fake conductor]]
- **Participant** : [[Hildegarde Schmidt]]
- **Participant** : [[Dr. Constantine]]
