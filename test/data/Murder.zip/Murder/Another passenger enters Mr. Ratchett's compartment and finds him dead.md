---
date: 1933-02-07
time: 1933-02-07T00:37:00
---


---

He rings the bell for the conductor, then panics and pretends to be Mr. Ratchett when answering as he doesn’t want to be found with the body.

---

- **When** : Tuesday 7 March 1933 00:37


- **Status** : Known Lie


- **Participant** : [[Unknown Intruder]]
- **Witness** : [[Mr Ratchett]]
- **Murder Theory** : [[Poirot’s Decoy Theory]]
- **Participant** : [[The Conductor]]
- **Participant** : [[Hector MacQueen]]
