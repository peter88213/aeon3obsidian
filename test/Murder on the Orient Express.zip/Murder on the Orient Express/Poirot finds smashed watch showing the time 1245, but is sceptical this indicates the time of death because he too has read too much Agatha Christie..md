The hands point to 1:15

- Participant: [[Poirot]]

- Clue: [[Smashed Watch showing 1245]]

#Clue

1933-02-07

11:45