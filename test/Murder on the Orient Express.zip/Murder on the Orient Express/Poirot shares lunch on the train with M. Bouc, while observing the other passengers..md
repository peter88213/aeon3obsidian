Each of the passengers is introduced and described in turn.

- Participant: [[Poirot]]

- Participant: [[Foscarelli]]

- Participant: [[Arbuthnot]]

- Participant: [[Count]]

- Participant: [[Countess]]

- Participant: [[Hardman]]

- Participant: [[Greta]]

- Participant: [[MacQueen]]

- Participant: [[Hildegarde]]

- Participant: [[M. Bouc]]

- Participant: [[Mary]]

- Participant: [[Ratchett]]

- Participant: [[Hubbard]]

- Participant: [[Princess]]