This indicates to him that something incriminating has been burnt

- Participant: [[Poirot]]

- Clue: [[Matches]]

#Clue

#Burnt_Paper

1933-02-07

11:35