




- **Participant** : [[Hercule Poirot]]
- **Participant** : [[M. Bouc]]
- **Relates to** : [[Tobacco Pipe Cleaners]]
- **Participant** : [[Dr. Constantine]]
