---
date: 1933-02-07
time: 1933-02-07T11:50:00
tags: 
  - Burnt_Paper
---


- **When** : Tuesday 7 March 1933 11:50


- **Status** : Established Fact


- **Participant** : [[Hercule Poirot]]
- **Clue** : [[Burnt letter mentioning Daisy Armstrong]]
