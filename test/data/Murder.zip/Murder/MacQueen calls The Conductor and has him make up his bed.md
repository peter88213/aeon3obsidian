---
date: 1933-02-07
time: 1933-02-07T00:52:00
tags: 
  - Alibi
---


- **When** : Tuesday 7 March 1933 00:52


- **Status** : Corroborated


- **Testimony** : [[Hector MacQueen's Testimony]]
- **Participant** : [[The Conductor]]
- **Witness** : [[Colonel Arbuthnot]]
- **Testimony** : [[The Conductor's Testimony]]
- **Participant** : [[Hector MacQueen]]
