- Participant: [[Poirot]]

[[Poirot finds conductors uniform in Hildegarde Schmidt's compartment]]

[[Poirot finds a bottle of a sleeping drug in Countess Andrenyi’s room]]

[[Poirot finds pipe cleaners in Arbuthnot’s compartment that match those found in Ratchett’s room]]

[[Poirot asks Mary Debenham about her “when its all over” comment the previous day.]]

1933-02-07

15:45

15 minutes