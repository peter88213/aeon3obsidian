- Participant: [[MacQueen]]

- Participant: [[Conductor]]

- Witness: [[Arbuthnot]]

- Testimony: [[The Conductor's Testimony]]

- Testimony: [[Hector MacQueen's Testimony]]

#Alibi

1933-02-07

00:52