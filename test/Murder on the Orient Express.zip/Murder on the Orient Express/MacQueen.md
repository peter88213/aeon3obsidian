MacQueen

Ratchett's personal secretary, his father was the prosecutor in the failed case.

- Relates to: [[Central Crime The Murder of Daisy Armstrong]]

1903-02-07

00:00