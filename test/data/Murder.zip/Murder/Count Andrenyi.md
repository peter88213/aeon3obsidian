---
date: 1902-02-13
time: 1902-02-13T00:00:00
aliases: 
  - Count
---


---

Countess Andrenyi’s husband

---

- **When** : Thursday 13 March 1902 0:00


- **Nationality** : Hungarian
- **Characteristics** : Protective of his wife
- **Motivation** : His wife is Daisy Armstrong’s aunt.
- **Gender** : Male
