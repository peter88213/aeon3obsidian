- Participant: [[Coroner]]

- Participant: [[Poirot]]

- Participant: [[M. Bouc]]

- Clue: [[Stab wounds]]