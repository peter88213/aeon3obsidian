




- **Participant** : [[Hercule Poirot]]
- **Participant** : [[Hector MacQueen]]
