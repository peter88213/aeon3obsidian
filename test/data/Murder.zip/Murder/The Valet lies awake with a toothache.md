---
date: 1933-02-06
time: 1933-02-06T22:30:00
tags: 
  - Alibi
---


- **When** : Monday 6 March 1933 22:30


- **Status** : Corroborated


- **Witness** : [[Antonio Foscarelli]]
- **Participant** : [[The Valet]]
- **Testimony** : [[The Valet's Testimony]]
