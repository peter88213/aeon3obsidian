




- [[Dr. Constantine]]
- [[M. Bouc]]
- [[Hercule Poirot]]
