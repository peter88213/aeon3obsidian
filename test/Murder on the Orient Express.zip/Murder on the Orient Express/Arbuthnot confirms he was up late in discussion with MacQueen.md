- Relates to: [[MacQueen talks politics with Colonel Arbuthnot]]

- Participant: [[Arbuthnot]]

- Participant: [[Poirot]]