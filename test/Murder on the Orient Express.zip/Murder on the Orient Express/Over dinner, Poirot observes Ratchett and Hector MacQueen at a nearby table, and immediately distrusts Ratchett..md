- Participant: [[Poirot]]

- Participant: [[MacQueen]]

- Participant: [[Ratchett]]