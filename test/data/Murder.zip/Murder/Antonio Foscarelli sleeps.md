---
date: 1933-02-07
time: 1933-02-07T04:00:00
tags: 
  - No_Alibi
---


- **When** : Tuesday 7 March 1933 04:00
- **Lasts** : 4 hours

- **Status** : Uncorroborated


- **Participant** : [[Antonio Foscarelli]]
- **Testimony** : [[Antonio Foscarelli's Testimony]]
- **Witness** : [[The Valet]]
