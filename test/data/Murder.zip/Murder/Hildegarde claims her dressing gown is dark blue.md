




- **Clue** : [[Scarlett Dressing Gown]]
- **Participant** : [[Hildegarde Schmidt]]
- **Participant** : [[Hercule Poirot]]
