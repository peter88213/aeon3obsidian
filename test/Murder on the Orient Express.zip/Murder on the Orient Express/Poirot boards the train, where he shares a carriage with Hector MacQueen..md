- Participant: [[Poirot]]

- Participant: [[MacQueen]]