- Witness: [[Poirot]]

- Murder Theory: [[True Crime]]

- Clue: [[Fake conductor]]

- Clue: [[Scarlett Dressing Gown]]

#Imposter_in_Kimono

1933-02-07

01:35