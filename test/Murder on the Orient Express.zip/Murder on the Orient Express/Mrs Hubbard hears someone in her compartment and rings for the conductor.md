- Witness: [[Hardman]]

- Witness: [[Poirot]]

- Participant: [[Conductor]]

- Testimony: [[Mrs Hubbard's Testimony]]

- Participant: [[Hubbard]]

- Clue: [[Intruder in Mrs Hubbard’s apartment]]

#Alibi

#Clue

1933-02-07

01:17

8 minutes