- Participant: [[Poirot]]

- Participant: [[Princess]]

[[After Poirot reveals Ratchett’s identitiy, Princess Dragomiroff reveals she knew Daisy’s grandmother, Linda Arden.]]

[[Princess Dragomiroff claims her dressing gown is black satin]]

1933-02-07

13:50

10 minutes