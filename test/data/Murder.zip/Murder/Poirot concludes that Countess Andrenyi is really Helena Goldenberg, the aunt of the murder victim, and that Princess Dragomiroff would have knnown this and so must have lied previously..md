




- **Participant** : [[Dr. Constantine]]
- **Clue** : [[Ratchett’s true identity]]
- **Participant** : [[M. Bouc]]
- **Participant** : [[Hercule Poirot]]
- **Clue** : [[Handkerchief with “H” monogram]]
