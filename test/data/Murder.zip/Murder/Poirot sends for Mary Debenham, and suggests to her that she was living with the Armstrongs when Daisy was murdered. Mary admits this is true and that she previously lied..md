---
date: 1933-02-07
time: 1933-02-07T19:30:00
---


- **When** : Tuesday 7 March 1933 19:30


- **Witness** : [[Dr. Constantine]]
- **Witness** : [[M. Bouc]]
- **Participant** : [[Hercule Poirot]]
- **Clue** : [[Ratchett’s true identity]]
- **Participant** : [[Mary Debenham]]
- **Witness** : [[Colonel Arbuthnot]]
