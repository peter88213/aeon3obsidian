- Participant: [[MacQueen]]

- Testimony: [[Hector MacQueen's Testimony]]

#No_Alibi

1933-02-07

01:45

6 hours