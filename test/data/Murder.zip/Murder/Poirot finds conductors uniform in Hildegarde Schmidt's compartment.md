---
date: 1933-02-07
time: 1933-02-07T15:55:00
tags: 
  - Clue
  - Imposter_Conductor_s_uniform
---


- **When** : Tuesday 7 March 1933 15:55


- **Status** : Established Fact


- **Participant** : [[Hercule Poirot]]
- **Clue** : [[Fake conductor]]
- **Witness** : [[Hildegarde Schmidt]]
