




- **Clue** : [[Scarlett Dressing Gown]]
- **Clue** : [[Handkerchief with “H” monogram]]
