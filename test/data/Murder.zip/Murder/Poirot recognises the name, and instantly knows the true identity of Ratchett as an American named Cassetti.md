---
date: 1933-02-07
time: 1933-02-07T11:58:00
tags: 
  - Burnt_Paper
---


---

A man responsible for the kidnap and murder of a little girl called Daisy Armstrong



---

- **When** : Tuesday 7 March 1933 11:58


- **Status** : Established Fact


- **Clue** : [[Burnt letter mentioning Daisy Armstrong]]
- **Clue** : [[Ratchett’s true identity]]
- **Participant** : [[Hercule Poirot]]
