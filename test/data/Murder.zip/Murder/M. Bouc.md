


---

A friend of Poirot’s who formerly worked for Belgian police, and is now Director of the company running the Orient Express.

He prematurely seizes on circumstancial evidence, acting as a “Dr Watson” within the plot. His primary purpose is to have Poirot correct him and explain his thoughts to him.

---



- **Characteristics** : Racist, distrusts italians
  Prematurely seizes on circumstancial evidence, acts in a “Doctor Watson” role that allows Poirot to talk to the reader by correcting him.
- **Gender** : Male
- **Motivation** : Asks Poirot to solve the case out of concern for company liabilities.
- **Nationality** : Belgian
