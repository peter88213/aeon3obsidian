#!/usr/bin/python3
"""Convert Aeon Timeline 3 project data to Obsidian Markdown fileset. 

usage: aeon3obsidian.py Sourcefile

positional arguments:
  Sourcefile  The path of the .aeon or .csv file.

Copyright (c) 2024 Peter Triesberger
For further information see https://github.com/peter88213/aeon3obsidian
Published under the MIT License (https://opensource.org/licenses/mit-license.php)
"""
import os
import sys
import json
import codecs


def scan_file(filePath):
    """Read and scan the project file.
    
    Positional arguments:
        filePath -- str: Path to the Aeon 3 project file.
    
    Return a string containing the JSON part.
    """
    with open(filePath, 'rb') as f:
        binInput = f.read()

    # JSON part: all characters between the first and last curly bracket.
    chrData = []
    opening = ord('{')
    closing = ord('}')
    level = 0
    for c in binInput:
        if c == opening:
            level += 1
        if level > 0:
            chrData.append(c)
            if c == closing:
                level -= 1
                if level == 0:
                    break
    if level != 0:
        raise ValueError('Error: Corrupted data.')

    jsonStr = codecs.decode(bytes(chrData), encoding='utf-8')
    if not jsonStr:
        raise ValueError('Error: No JSON part found.')

    return jsonStr


class Aeon3File:

    def __init__(self, filePath):
        """Set the Aeon 3 project file path."""
        self.filePath = filePath
        self.dataModel = {}
        self.labelLookup = {}

    def _read_item(self, aeonItem):
        """Return a dictionary with the relevant item properties."""
        item = {}
        item['shortLabel'] = aeonItem['shortLabel']
        item['summary'] = aeonItem['summary']
        return item

    def read(self):
        """Read the Aeon 3 project file.
        
        Store the relevant data in the dataModel dictionary.
        Populate the labelLookup dictionary.
        
        Return a success message.
        """

        #--- Read the aeon file and get a JSON data structure.
        jsonPart = scan_file(self.filePath)
        jsonData = json.loads(jsonPart)

        #--- Create a labelLookup dictionary for types and relationships.
        for uid in jsonData['definitions']['types']['byId']:
            element = jsonData['definitions']['types']['byId'][uid].get('label', None)
            if element:
                self.labelLookup[uid] = element
        for uid in jsonData['definitions']['references']['byId']:
            element = jsonData['definitions']['references']['byId'][uid].get('label', None)
            if element:
                self.labelLookup[uid] = element
        for uid in jsonData['data']['tags']:
            element = jsonData['data']['tags'][uid]
            self.labelLookup[uid] = element

        #--- Create a data model and extend the labelLookup dictionary.
        for uid in jsonData['data']['items']['byId']:
            aeonItem = jsonData['data']['items']['byId'][uid]
            self.labelLookup[uid] = aeonItem['label']
            self.dataModel[uid] = self._read_item(aeonItem)

        return 'Aeon 3 file successfully read.'



class ObsidianFiles:
    FORBIDDEN_CHARACTERS = ('\\', '/', ':', '*', '?', '"', '<', '>', '|')
    # set of characters that filenames cannot contain

    def __init__(self, folderPath):
        """Set the Obsidian folder."""
        self.folderPath = folderPath
        self.dataModel = {}
        self.labelLookup = {}

    def _build_content(self, item):
        """Return a string with the Markdown file content.
        
        Positional arguments:
            item: dictionary of Aeon item properties.
        """
        lines = []
        for itemProperty in item:
            if item[itemProperty]:
                lines.append(item[itemProperty])
        return '\n\n'.join(lines)

    def write(self):
        """Create a set of Markdown files in the Obsidian folder.
        
        Return a success message.
        """
        os.makedirs(self.folderPath, exist_ok=True)
        for uid in self.dataModel:
            title = self._strip_title(self.labelLookup[uid])
            text = self._build_content(self.dataModel[uid])
            self._write_file(f'{self.folderPath}/{title}.md', text)
        return 'Obsidian files successfully written.'

    def _write_file(self, filePath, text):
        """Write a single file and create a backup copy, if applicable.
        
        Positional arguments:
            filePath: str -- Path of the file to write.
            text: str -- File content.
        """
        backedUp = False
        if os.path.isfile(filePath):
            try:
                os.replace(filePath, f'{filePath}.bak')
                backedUp = True
            except Exception as ex:
                raise Exception(f'Error: Cannot overwrite "{os.path.normpath(filePath)}": {str(ex)}.')

        try:
            with open(filePath, 'w', encoding='utf-8') as f:
                f.write(text)
        except Exception as ex:
            if backedUp:
                os.replace(f'{filePath}.bak', self.filePath)
            raise Exception(f'Error: Cannot write "{os.path.normpath(filePath)}": {str(ex)}.')

        return f'"{os.path.normpath(filePath)}" written.'

    def _strip_title(self, title):
        """Return title with characters removed that must not appear in a file name."""
        for c in self.FORBIDDEN_CHARACTERS:
            title = title.replace(c, '')
        return title



def main(sourcePath):
    """Convert an .aeon source file to a set of Markdown files.
    
    Positional arguments:
        sourcePath -- str: The path of the .aeon file.
        
    """
    # Create an Aeon 3 file object and read the data.
    aeon3File = Aeon3File(sourcePath)
    print(aeon3File.read())

    # Define the output directory.
    aeonDir, aeonFilename = os.path.split(sourcePath)
    projectName = os.path.splitext(aeonFilename)[0]
    obsidianFolder = os.path.join(aeonDir, projectName)

    # Create an Obsidian fileset object and write the data.
    obsidianFiles = ObsidianFiles(obsidianFolder)
    obsidianFiles.dataModel = aeon3File.dataModel
    obsidianFiles.labelLookup = aeon3File.labelLookup
    print(obsidianFiles.write())


if __name__ == '__main__':
    main(sys.argv[1])
