




- **Participant** : [[Hercule Poirot]]
- **Clue** : [[Scarlett Dressing Gown]]
- **Participant** : [[Hildegarde Schmidt]]
