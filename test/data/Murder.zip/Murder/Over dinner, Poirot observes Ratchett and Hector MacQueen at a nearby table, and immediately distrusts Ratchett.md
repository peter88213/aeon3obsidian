




- **Participant** : [[Hercule Poirot]]
- **Participant** : [[Mr Ratchett]]
- **Participant** : [[Hector MacQueen]]
