




- **Participant** : [[Hercule Poirot]]
- **See also** : [[Greta Ohlsson is observed by Mrs Hubbard entering Rachett's apartment by mistake]]
- **Participant** : [[Greta Ohlsson]]
- **See also** : [[Mrs Hubbard asks Greta Ohlsson to confirm the door to Ratchett’s room is bolted]]
