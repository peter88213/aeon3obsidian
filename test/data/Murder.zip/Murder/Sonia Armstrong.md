


---

Mother of murder victim Daisy Armstrong, she miscarried and died as a result of stress from the assault

---

