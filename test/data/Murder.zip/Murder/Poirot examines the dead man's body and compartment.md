---
date: 1933-02-07
time: 1933-02-07T11:30:00
---


---

12 stab wounds to the body

Ratchett was already dead for some time before some of the stabs

Some left handed, some right handed

Some weak, some strong



---

- **When** : Tuesday 7 March 1933 11:30


- **Participant** : [[Hercule Poirot]]
- **Participant** : [[Dr. Constantine]]


- [[Poirot finds a smashed watch showing the time 1245, but is sceptical this indicates the time of death]]
- [[Poirot finds tobacco pipe]]
- [[Poirot finds scrap of paper with the words -member little Daisy Armstrong]]
- [[Poirot recognises the name, and instantly knows the true identity of Ratchett as an American named Cassetti]]
- [[Poirot finds women's handkerchief with the initial 'H']]
- [[Poirot finds two different kinds of matches in compartment]]
- [[Poirot notices some stab wounds were delivered right handed, and others left handed; some are deep and some mere scratches]]
