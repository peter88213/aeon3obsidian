---
date: 1933-02-07
time: 1933-02-07T15:45:00
---


---

He is looking to find the missing dressing gown and conductor’s uniform

---

- **When** : Tuesday 7 March 1933 15:45
- **Lasts** : 15 minutes

- **Participant** : [[Hercule Poirot]]


- [[Poirot finds conductors uniform in Hildegarde Schmidt's compartment]]
- [[Poirot finds a bottle of a sleeping drug in Countess Andrenyi’s room]]
- [[Poirot finds pipe cleaners in Arbuthnot’s compartment that match those found in Ratchett’s room]]
- [[Poirot asks Mary Debenham about her “when its all over” comment the previous day]]
