---
date: 1933-02-07
time: 1933-02-07T19:15:00
---


- **When** : Tuesday 7 March 1933 19:15


- **Participant** : [[Hercule Poirot]]
- **Witness** : [[M. Bouc]]
- **Witness** : [[Dr. Constantine]]
- **Clue** : [[Handkerchief with “H” monogram]]
- **Clue** : [[Ratchett’s true identity]]
- **Participant** : [[Princess Dragonmiroff]]
