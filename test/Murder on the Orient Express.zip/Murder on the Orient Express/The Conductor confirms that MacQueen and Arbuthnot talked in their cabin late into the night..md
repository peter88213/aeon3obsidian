- Participant: [[Poirot]]

- See also: [[MacQueen talks politics with Colonel Arbuthnot]]

- Participant: [[Conductor]]