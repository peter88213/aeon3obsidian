- Participant: [[Poirot]]

- Participant: [[Mary]]

- Witness: [[M. Bouc]]

- Witness: [[Coroner]]

- Participant: [[Arbuthnot]]

1933-02-07

19:30

6 minutes