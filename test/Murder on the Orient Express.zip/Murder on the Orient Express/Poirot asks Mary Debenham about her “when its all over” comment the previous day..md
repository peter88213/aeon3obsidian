- Clue: [[Overheard “When it’s all over]]

- Participant: [[Poirot]]

- Participant: [[Mary]]