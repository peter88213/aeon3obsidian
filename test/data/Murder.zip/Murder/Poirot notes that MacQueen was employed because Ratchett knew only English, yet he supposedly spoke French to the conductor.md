




- **Clue** : [[French reply from door]]
- **Participant** : [[Dr. Constantine]]
- **Participant** : [[M. Bouc]]
- **Participant** : [[Hercule Poirot]]
