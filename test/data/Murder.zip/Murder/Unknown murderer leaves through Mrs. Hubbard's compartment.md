---
date: 1933-02-07
time: 1933-02-07T00:20:00
---


---

Leaves behind murder weapon and button from cloak



---

- **When** : Tuesday 7 March 1933 0:20


- **Status** : Known Lie


- **Participant** : [[Unknown Intruder]]
- **Witness** : [[Mrs Hubbard]]
- **Murder Theory** : [[Poirot’s Decoy Theory]]
