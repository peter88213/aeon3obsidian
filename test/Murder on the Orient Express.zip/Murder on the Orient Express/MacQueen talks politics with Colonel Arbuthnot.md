- Participant: [[MacQueen]]

- Testimony: [[Colonel Arbuthnot's Testimony]]

- Participant: [[Arbuthnot]]

- Testimony: [[Hector MacQueen's Testimony]]

#Alibi

1933-02-06

22:00

225 minutes