---
date: 1933-02-07
time: 1933-02-07T19:20:00
---


- **When** : Tuesday 7 March 1933 19:20


- [[Poirot asks Arbuthnot about his conversation with Ms Debenham in Syria, which he refuses to answer]]
- [[Poirot again confronts Colonel Arbuthnot regarding the pipe-cleaner, but Arbuthnot stonewalls him]]
- [[Poirot confronts Arbuthnot with a guess that Mary Debenham was the Countess’s governess. Arbuthnot silence confirms to Poirot that he is correct]]
