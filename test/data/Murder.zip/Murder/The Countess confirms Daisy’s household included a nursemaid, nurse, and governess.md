---
date: 1933-02-07
time: 1933-02-07T19:12:00
---


- **When** : Tuesday 7 March 1933 19:12


- **Witness** : [[M. Bouc]]
- **Witness** : [[Count Andrenyi]]
- **Participant** : [[Countess Andrenyi]]
- **Clue** : [[Ratchett’s true identity]]
- **Participant** : [[Hercule Poirot]]
