After this time it was impossible for anyone to leave the train



- Story Arc: [[Train Movements]]

- Clue: [[Open Window]]

- Clue: [[No Footprints]]

#Clue

#Train_Movement

1933-02-07

00:30

9 hours, 15 minutes