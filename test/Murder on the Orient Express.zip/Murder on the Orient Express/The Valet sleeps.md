- Testimony: [[The Valet's Testimony]]

- Witness: [[Foscarelli]]

- Participant: [[Valet]]

#No_Alibi

1933-02-07

04:00

4 hours