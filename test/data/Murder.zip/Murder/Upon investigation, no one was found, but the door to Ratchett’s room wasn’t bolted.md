




- **Participant** : [[Hercule Poirot]]
- **Clue** : [[Locked Compartment]]
