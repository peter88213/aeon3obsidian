Nursemaid

Committed suicide following Daisy Armstrong’s murder, when police suspicion turned to her.

- Nurse: [[Daisy]]

- Parent: [[Conductor]]