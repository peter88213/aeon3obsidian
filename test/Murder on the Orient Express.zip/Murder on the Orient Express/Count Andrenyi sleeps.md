This alibi does not cover the time period 1-1:15 am

- Testimony: [[Count Andrenyi's Testimony]]

- Participant: [[Count]]

#Partial_Alibi

1933-02-06

23:10

530 minutes