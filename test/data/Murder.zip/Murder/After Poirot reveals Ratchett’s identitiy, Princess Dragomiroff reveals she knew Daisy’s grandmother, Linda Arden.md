




- **Participant** : [[Hercule Poirot]]
- **Participant** : [[Princess Dragonmiroff]]
- **Clue** : [[Ratchett’s true identity]]
