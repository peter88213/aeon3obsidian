




- **Participant** : [[Hercule Poirot]]
- **Witness** : [[Dr. Constantine]]
- **Witness** : [[M. Bouc]]
