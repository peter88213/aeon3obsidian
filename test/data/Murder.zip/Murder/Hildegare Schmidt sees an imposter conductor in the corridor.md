---
date: 1933-02-07
time: 1933-02-07T01:17:00
tags: 
  - No_Alibi
  - Clue
  - Imposter_Conductor_s_uniform
---


- **When** : Tuesday 7 March 1933 1:17


- **Testimony** : [[Hildegarde Schmidt's Testimony]]
- **Clue** : [[Fake conductor]]
- **Witness** : [[Hector MacQueen]]
- **Participant** : [[Hildegarde Schmidt]]
- **Witness** : [[Colonel Arbuthnot]]
