---
date: 1933-02-07
time: 1933-02-07T13:31:00
---


- **When** : Tuesday 7 March 1933 13:31


- **Participant** : [[Mrs Hubbard]]
- **Participant** : [[Hercule Poirot]]


- [[Poirot informs Mrs Hubbard of Ratchett’s true identity, but she denies a connection]]
- [[Mrs Hubbard claims the murderer entered her room the previous night, as she awoke to a shadowy figure. She called the conductor, as witnessed by Poirot]]
- [[Mrs Hubbard hands Poirot a button from a train conductor’s uniform which she found near her bed]]
- [[Upon investigation, no one was found, but the door to Ratchett’s room wasn’t bolted]]
- [[Mrs Hubbard denies owning a red dressing gown, and says the handkerchief with “H” written on it is not hers]]
