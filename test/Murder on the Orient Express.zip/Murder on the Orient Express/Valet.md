Valet

Acting as Mr Ratchett’s personal valet, he was the personal servant of Colonel Armstrong, Daisy’s father.

- Associate: [[Colonel Armstrong]]

- Associate: [[Ratchett]]