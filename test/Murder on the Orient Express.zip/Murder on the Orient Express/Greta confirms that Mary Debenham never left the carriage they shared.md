- See also: [[Mary Debenham sleeps]]

- Participant: [[Poirot]]

- Participant: [[Greta]]