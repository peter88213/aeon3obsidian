---
date: 1933-02-07
time: 1933-02-07T05:10:00
tags: 
  - No_Alibi
---


- **When** : Tuesday 7 March 1933 5:10


- **Status** : Corroborated


- **Witness** : [[Greta Ohlsson]]
- **Participant** : [[Mary Debenham]]
- **Testimony** : [[Mary Debenham's Testimony]]
