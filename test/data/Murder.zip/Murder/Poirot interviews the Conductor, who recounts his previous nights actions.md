---
date: 1933-02-07
time: 1933-02-07T13:10:00
---


- **When** : Tuesday 7 March 1933 13:10


- **Participant** : [[The Conductor]]
- **Participant** : [[Hercule Poirot]]


- [[The Conductor recounts bringing mineral water to Poirot]]
- [[The Conductor confirms that MacQueen and Arbuthnot talked in their cabin late into the night]]
- [[The Conductor recounts responding to Ratchett’s bell, as Poirot had witnessed on the night]]
