- Participant: [[Poirot]]

- Participant: [[Conductor]]