- Participant: [[Poirot]]

- Participant: [[Countess]]

- Participant: [[Count]]

[[The Countess claims her husband smokes cigarettes and cigars, but not a pipe]]

[[The Countess claims her dressing gown is yellow]]

1933-02-07

14:00

10 minutes