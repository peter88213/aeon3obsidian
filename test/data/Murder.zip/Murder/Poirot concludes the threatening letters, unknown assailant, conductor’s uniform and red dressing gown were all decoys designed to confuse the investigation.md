---
date: 1933-02-07
time: 1933-02-07T20:15:00
---


- **When** : Tuesday 7 March 1933 20:15
- **Lasts** : 3 minutes

- **Witness** : [[Count Andrenyi]]
- **Witness** : [[M. Bouc]]
- **Clue** : [[Intruder in Mrs Hubbard’s apartment]]
- **Witness** : [[Countess Andrenyi]]
- **Witness** : [[Princess Dragonmiroff]]
- **Witness** : [[Mrs Hubbard]]
- **Clue** : [[Fake conductor]]
- **Witness** : [[The Conductor]]
- **Witness** : [[Greta Ohlsson]]
- **Clue** : [[Threatening letters]]
- **Witness** : [[Colonel Arbuthnot]]
- **Participant** : [[Hercule Poirot]]
- **Witness** : [[Dr. Constantine]]
- **Witness** : [[Hildegarde Schmidt]]
- **Clue** : [[Scarlett Dressing Gown]]
- **Witness** : [[Hector MacQueen]]
- **Witness** : [[The Valet]]
- **Witness** : [[Mary Debenham]]
- **Witness** : [[Cyrus Hardman]]
- **Witness** : [[Antonio Foscarelli]]
