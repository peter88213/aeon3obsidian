She lies about hearing a man in her compartment



- Witness: [[Poirot]]

- Participant: [[Conductor]]

- Participant: [[Hubbard]]

- Murder Theory: [[True Crime]]

- Clue: [[Fake conductor]]

- Clue: [[Intruder in Mrs Hubbard’s apartment]]

1933-02-07

01:17