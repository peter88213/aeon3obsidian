---
date: 1933-02-06
time: 1933-02-06T22:40:00
---


- **When** : Monday 6 March 1933 22:40


- **Status** : Corroborated


- **Participant** : [[Greta Ohlsson]]
- **Testimony** : [[Mrs Hubbard's Testimony]]
- **Witness** : [[Mrs Hubbard]]
- **Testimony** : [[Greta Ohlsson's Testimony]]
- **Participant** : [[Mr Ratchett]]
