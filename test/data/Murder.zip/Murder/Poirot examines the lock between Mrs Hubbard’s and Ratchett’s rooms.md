---
date: 1933-02-07
time: 1933-02-07T15:35:00
---


---

He believes it may have only been locked from Ratchett’s side.

---

- **When** : Tuesday 7 March 1933 15:35


- **Witness** : [[Mrs Hubbard]]
- **Participant** : [[Hercule Poirot]]
- **Witness** : [[M. Bouc]]
- **Clue** : [[Locked Compartment]]
