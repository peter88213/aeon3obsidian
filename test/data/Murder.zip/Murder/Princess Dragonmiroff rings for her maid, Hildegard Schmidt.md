---
date: 1933-02-07
time: 1933-02-07T00:45:00
tags: 
  - Alibi
---


- **When** : Tuesday 7 March 1933 0:45


- **Status** : Corroborated


- **Testimony** : [[Princess Dragomiroff's Testimony]]
- **Witness** : [[The Conductor]]
- **Participant** : [[Princess Dragonmiroff]]
