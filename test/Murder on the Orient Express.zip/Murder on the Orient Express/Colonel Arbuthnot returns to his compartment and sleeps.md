- Witness: [[Conductor]]

- Testimony: [[Colonel Arbuthnot's Testimony]]

- Participant: [[Arbuthnot]]

#No_Alibi

1933-02-07

01:45

375 minutes