- Witness: [[Poirot]]

- Participant: [[Conductor]]

- Witness: [[Ratchett]]

- Testimony: [[The Conductor's Testimony]]

- Clue: [[French reply from door]]

#Clue

1933-02-07

00:37