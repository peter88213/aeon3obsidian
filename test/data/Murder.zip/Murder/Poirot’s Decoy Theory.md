


---

Poirot proposes a decoy solution in which an unknown murderer enters the train, murders Mr Ratchett, and then flees the train prior to the discovery of the body.

---

