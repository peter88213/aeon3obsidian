- Participant: [[Conductor]]

- Witness: [[Ratchett]]

1933-02-07

10:40