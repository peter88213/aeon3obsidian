---
date: 1933-02-07
time: 1933-02-07T00:25:00
---


- **When** : Tuesday 7 March 1933 0:25


- **Status** : Known Lie


- **Participant** : [[Unknown Intruder]]
- **Murder Theory** : [[Poirot’s Decoy Theory]]
