- Clue: [[Scarlett Dressing Gown]]

- Participant: [[Hildegarde]]

- Participant: [[Poirot]]