---
date: 1933-02-07
time: 1933-02-07T01:45:00
tags: 
  - Murder_Weapon
  - Hankerchief
  - Pipe
---


---

They were all in on it. Countess Andrenyi, though aware of the plan, was the only one that did not take part.

The pipe and handkerchief were left in the compartment to confuse Poirot.

This explains the different times of death and the different types of stabbing



---

- **When** : Tuesday 7 March 1933 1:45


- **Status** : Established Fact


- **Murder Theory** : [[The Real Crime]]
- **Participant** : [[Mr Ratchett]]
- **Participant** : [[Princess Dragonmiroff]]
- **Participant** : [[Mrs Hubbard]]
- **Participant** : [[Greta Ohlsson]]
- **Participant** : [[Count Andrenyi]]
- **Participant** : [[Antonio Foscarelli]]
- **Participant** : [[The Conductor]]
- **Participant** : [[Hildegarde Schmidt]]
- **Participant** : [[Colonel Arbuthnot]]
- **Participant** : [[The Valet]]
- **Participant** : [[Cyrus Hardman]]
- **Participant** : [[Hector MacQueen]]
- **Participant** : [[Mary Debenham]]
