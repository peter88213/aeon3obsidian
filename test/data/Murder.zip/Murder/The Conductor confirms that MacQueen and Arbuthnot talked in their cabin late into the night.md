




- **Participant** : [[Hercule Poirot]]
- **See also** : [[MacQueen talks politics with Colonel Arbuthnot]]
- **Participant** : [[The Conductor]]
