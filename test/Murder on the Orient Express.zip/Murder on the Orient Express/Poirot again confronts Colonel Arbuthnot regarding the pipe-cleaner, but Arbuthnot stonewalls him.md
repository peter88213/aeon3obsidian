- Participant: [[Poirot]]

- Participant: [[Arbuthnot]]

- Witness: [[M. Bouc]]

- Witness: [[Coroner]]

- Clue: [[Tobacco Pipe Cleaners]]

1933-02-07

19:25

5 minutes