




- **Participant** : [[Hildegarde Schmidt]]
- **See also** : [[Greta Ohlsson returns to her compartment and sleeps]]
- **See also** : [[Mary Debenham sleeps]]
- **Participant** : [[Hercule Poirot]]
