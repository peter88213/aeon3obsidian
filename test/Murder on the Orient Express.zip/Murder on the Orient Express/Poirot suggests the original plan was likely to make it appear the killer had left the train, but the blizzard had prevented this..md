- Clue: [[No Footprints]]

- Clue: [[Open Window]]

- Clue: [[Fake conductor]]

- Participant: [[Poirot]]

- Participant: [[M. Bouc]]

- Participant: [[Coroner]]