


---

He overhears MacQueen and Arbuthnot planning further discussion in MacQueen’s carriage

---



- **Participant** : [[Hercule Poirot]]
