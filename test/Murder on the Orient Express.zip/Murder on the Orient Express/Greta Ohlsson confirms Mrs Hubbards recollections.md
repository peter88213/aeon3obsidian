- See also: [[Greta Ohlsson is observed by Mrs Hubbard entering Rachett's apartment by mistake]]

- See also: [[Mrs Hubbard asks Greta Ohlsson to confirm the door to Ratchett’s room is bolted before she goes to bed.]]

- Participant: [[Poirot]]

- Participant: [[Greta]]