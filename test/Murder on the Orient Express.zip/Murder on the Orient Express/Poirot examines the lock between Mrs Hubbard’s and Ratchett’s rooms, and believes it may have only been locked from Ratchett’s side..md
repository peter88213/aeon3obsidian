- Clue: [[Locked Compartment]]

- Participant: [[Poirot]]

- Witness: [[Hubbard]]

- Witness: [[M. Bouc]]

1933-02-07

15:35