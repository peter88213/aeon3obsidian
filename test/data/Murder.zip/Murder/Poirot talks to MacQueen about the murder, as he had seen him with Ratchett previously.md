---
date: 1933-02-07
time: 1933-02-07T11:10:00
---


- **When** : Tuesday 7 March 1933 11:10
- **Lasts** : 20 minutes

- **Participant** : [[Hercule Poirot]]
- **Participant** : [[Hector MacQueen]]
- **Participant** : [[The Conductor]]


- [[MacQueen provides testimony that he last saw Ratchett when he took down a memoranda of letters]]
- [[MacQueen shows Poirot the threatening letters left for Ratchett, which Poirot determines were written by several different people.]]
- [[MacQueen mentions that he believes Ratchett’s name is an alias]]
- [[MacQueen mentions that he travels with Ratchett because Ratchett does not know any languages]]
