---
date: 1933-02-07
time: 1933-02-07T15:30:00
tags: 
  - Murder_Weapon
---


- **When** : Tuesday 7 March 1933 15:30


- **Status** : Established Fact


- **Witness** : [[Hercule Poirot]]
- **Clue** : [[Bloody knife]]
- **Participant** : [[Mrs Hubbard]]
