




- **Clue** : [[Fake conductor]]
- **Clue** : [[Open Window]]
- **Clue** : [[No Footprints]]
- **Participant** : [[Hercule Poirot]]
- **Participant** : [[M. Bouc]]
- **Participant** : [[Dr. Constantine]]
