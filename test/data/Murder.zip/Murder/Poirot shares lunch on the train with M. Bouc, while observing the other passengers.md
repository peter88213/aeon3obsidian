


---

Each of the passengers is introduced and described in turn.

---



- **Participant** : [[Mrs Hubbard]]
- **Participant** : [[Colonel Arbuthnot]]
- **Participant** : [[Cyrus Hardman]]
- **Participant** : [[Hildegarde Schmidt]]
- **Participant** : [[Mary Debenham]]
- **Participant** : [[Antonio Foscarelli]]
- **Participant** : [[Hercule Poirot]]
- **Participant** : [[Greta Ohlsson]]
- **Participant** : [[Mr Ratchett]]
- **Participant** : [[Princess Dragonmiroff]]
- **Participant** : [[Countess Andrenyi]]
- **Participant** : [[M. Bouc]]
- **Participant** : [[Count Andrenyi]]
- **Participant** : [[Hector MacQueen]]
