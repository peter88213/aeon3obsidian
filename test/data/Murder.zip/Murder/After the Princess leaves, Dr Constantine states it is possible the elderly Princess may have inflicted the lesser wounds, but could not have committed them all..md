




- **Clue** : [[Stab wounds]]
- **Participant** : [[Dr. Constantine]]
- **Participant** : [[Hercule Poirot]]
- **Participant** : [[M. Bouc]]
