- Clue: [[Bloody knife]]

- Participant: [[Poirot]]

- Witness: [[M. Bouc]]