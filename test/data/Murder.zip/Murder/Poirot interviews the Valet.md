---
date: 1933-02-07
time: 1933-02-07T13:20:00
---


- **When** : Tuesday 7 March 1933 13:20
- **Lasts** : 10 minutes

- **Participant** : [[The Valet]]
- **Participant** : [[Hercule Poirot]]


- [[Poirot asks The Valet if he is a pipe smoker, but he claims he only smokes cigarettes]]
