- Participant: [[Poirot]]

- See also: [[MacQueen takes down memoranda of letters with Mr Ratchett. This is observed by the Conductor, who states that no one else was seen entering Ratchett’s room that night.]]

1933-02-07

11:10:06

19 minutes, 54 seconds