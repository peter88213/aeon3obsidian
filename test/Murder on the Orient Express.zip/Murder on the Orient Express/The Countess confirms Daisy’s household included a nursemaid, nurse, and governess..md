- Participant: [[Poirot]]

- Participant: [[Countess]]

- Witness: [[Count]]

- Witness: [[M. Bouc]]

- Clue: [[Ratchett’s true identity]]

1933-02-07

19:12

3 minutes