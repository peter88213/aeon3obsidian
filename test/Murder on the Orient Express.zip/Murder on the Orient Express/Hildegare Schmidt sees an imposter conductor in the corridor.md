- Witness: [[MacQueen]]

- Testimony: [[Hildegarde Schmidt's Testimony]]

- Witness: [[Arbuthnot]]

- Participant: [[Hildegarde]]

- Clue: [[Fake conductor]]

#No_Alibi

#Clue

#Imposter_in_Conductor's_uniform

1933-02-07

01:17