- Participant: [[Poirot]]

- Clue: [[Scarlett Dressing Gown]]

#Clue

#Imposter_in_Kimono

1933-02-07

16:00