- Clue: [[French reply from door]]

- Participant: [[Poirot]]

- Participant: [[Coroner]]

- Participant: [[M. Bouc]]