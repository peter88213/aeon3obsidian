---
date: 1933-02-07
time: 1933-02-07T00:37:00
---


---

As Mr. Ratchett does not speak French, this is to imply to Poirot that he was already dead at this point



---

- **When** : Tuesday 7 March 1933 0:37


- **Status** : Established Fact


- **Clue** : [[French reply from door]]
- **Participant** : [[The Conductor]]
- **Relates to** : [[French reply from door]]
- **Murder Theory** : [[The Real Crime]]
- **Witness** : [[Hercule Poirot]]
