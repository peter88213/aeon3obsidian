---
date: 1933-02-07
time: 1933-02-07T00:16:00
---


- **When** : Tuesday 7 March 1933 00:16


- **Status** : Known Lie


- **Witness** : [[Mr Ratchett]]
- **Murder Theory** : [[Poirot’s Decoy Theory]]
- **Participant** : [[Unknown Intruder]]
- **Participant** : [[Mr Ratchett]]
