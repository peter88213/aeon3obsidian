- Participant: [[Poirot]]

- Witness: [[M. Bouc]]

- Witness: [[Coroner]]

- Clue: [[Ratchett’s true identity]]

- Participant: [[Valet]]

1933-02-07

19:40

5 minutes