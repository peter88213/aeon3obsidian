---
aliases: 
  - Daisy
---




- **Parent** : [[Colonel Armstrong]]
- **Parent** : [[Sonia Armstrong]]
- **Relates to** : [[Central Crime The Murder of Daisy Armstrong]]
