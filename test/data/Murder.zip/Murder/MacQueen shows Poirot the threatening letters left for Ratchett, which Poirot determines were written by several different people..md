---
date: 1933-02-07
time: 1933-02-07T11:10:00
---


- **When** : Tuesday 7 March 1933 11:10


- **Participant** : [[Hercule Poirot]]
- **Clue** : [[Threatening letters]]
