---
date: 1933-02-07
time: 1933-02-07T13:10:00
---


- **When** : Tuesday 7 March 1933 13:10


- **Participant** : [[Hector MacQueen]]
- **Participant** : [[Hercule Poirot]]


- [[Poirot informs MacQueen of Ratchett’s real identity. MacQueen reacts with surprise, and reveals his connection to the Armstrong case]]
