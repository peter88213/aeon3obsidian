---
date: 1933-02-07
time: 1933-02-07T00:37:00
tags: 
  - Clue
---


---

Rachett replies in French to assure him he is okay.

---

- **When** : Tuesday 7 March 1933 00:37


- **Status** : Established Fact


- **Testimony** : [[The Conductor's Testimony]]
- **Clue** : [[French reply from door]]
- **Witness** : [[Mr Ratchett]]
- **Witness** : [[Hercule Poirot]]
- **Participant** : [[The Conductor]]
- **Participant** : [[Hercule Poirot]]
