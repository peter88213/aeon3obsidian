---
date: 1933-02-07
time: 1933-02-07T04:59:00
tags: 
  - No_Alibi
  - Clue
  - Imposter_in_Kimono
---


- **When** : Tuesday 7 March 1933 4:59


- **Status** : Uncorroborated


- **Clue** : [[Scarlett Dressing Gown]]
- **Participant** : [[Mary Debenham]]
- **Testimony** : [[Mary Debenham's Testimony]]
