---
date: 1933-02-06
time: 1933-02-06T21:00:00
---


- **When** : Monday 6 March 1933 21:00
- **Lasts** : 40 minutes

- **Status** : Uncorroborated


- **Participant** : [[Mr Ratchett]]
- **Testimony** : [[The Valet's Testimony]]
- **Participant** : [[The Valet]]
- **Witness** : [[The Conductor]]
