---
date: 1933-02-07
time: 1933-02-07T20:09:00
---


- **When** : Tuesday 7 March 1933 20:09


- **Witness** : [[Colonel Arbuthnot]]
- **Witness** : [[Mrs Hubbard]]
- **Witness** : [[Countess Andrenyi]]
- **Witness** : [[Hildegarde Schmidt]]
- **Witness** : [[Antonio Foscarelli]]
- **Witness** : [[Cyrus Hardman]]
- **Witness** : [[Count Andrenyi]]
- **Witness** : [[Dr. Constantine]]
- **Relates to** : [[The Real Crime]]
- **Witness** : [[Greta Ohlsson]]
- **Witness** : [[Mary Debenham]]
- **Witness** : [[Hector MacQueen]]
- **Witness** : [[Princess Dragonmiroff]]
- **Participant** : [[Hercule Poirot]]
- **Witness** : [[The Valet]]
- **Witness** : [[The Conductor]]
- **Witness** : [[M. Bouc]]
