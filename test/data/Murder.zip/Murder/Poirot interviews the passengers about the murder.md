---
date: 1933-02-07
time: 1933-02-07T13:10:00
---


- **When** : Tuesday 7 March 1933 13:10
- **Lasts** : 2 hours

- **Participant** : [[Hercule Poirot]]
- **Participant** : [[M. Bouc]]


- [[After Foscarelli leaves, M. Bouc shows his prejudice by insisting it must be him because Italians use knives]]
- [[Poirot interviews MacQueen]]
- [[Poirot interviews Mary Debenham, who is uncooperative and evasive during the interview]]
- [[Poirot interviews Princess Drawgonmiroff]]
- [[Poirot interviews Cyrus Hardman]]
- [[Poirot interviews the Valet]]
- [[Poirot interviews Antonio Foscarelli]]
- [[Poirot interviews Greta Ohlsson]]
- [[Poirot interviews Count and Countess Andrenyi]]
- [[Poirot interviews Hildegarde Schmidt]]
- [[Poirot interviews Mrs Hubbard]]
- [[Poirot interviews the Conductor, who recounts his previous nights actions]]
- [[Poirot asks The Conductor about the button found by Mrs Hubbard, but he denies it is his and finds colleagues to vouch for his whereabouts]]
- [[Poirot interviews Colonel Arbuthnot]]
