- Participant: [[Poirot]]

- Participant: [[Valet]]

- Clue: [[Tobacco Pipe Cleaners]]