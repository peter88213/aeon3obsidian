




- **Clue** : [[Handkerchief with “H” monogram]]
