- Testimony: [[Princess Dragomiroff's Testimony]]

- Testimony: [[Hildegarde Schmidt's Testimony]]

- Participant: [[Princess]]

- Participant: [[Hildegarde]]

#Alibi

1933-02-07

00:46

29 minutes