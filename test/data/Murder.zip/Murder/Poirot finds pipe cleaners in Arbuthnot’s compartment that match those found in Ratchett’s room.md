




- **Participant** : [[Hercule Poirot]]
- **Witness** : [[Colonel Arbuthnot]]
- **Clue** : [[Tobacco Pipe Cleaners]]
