---
date: 1933-02-06
time: 1933-02-06T22:41:00
tags: 
  - Alibi
---


- **When** : Monday 6 March 1933 22:41


- **Status** : Corroborated


- **Testimony** : [[Mrs Hubbard's Testimony]]
- **Participant** : [[Greta Ohlsson]]
- **Participant** : [[Mrs Hubbard]]
- **Testimony** : [[Greta Ohlsson's Testimony]]
