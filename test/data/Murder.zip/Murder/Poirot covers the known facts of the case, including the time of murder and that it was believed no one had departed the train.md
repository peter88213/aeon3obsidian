---
date: 1933-02-07
time: 1933-02-07T20:00:00
---


- **When** : Tuesday 7 March 1933 20:00
- **Lasts** : 3 minutes

- **Witness** : [[Colonel Arbuthnot]]
- **Witness** : [[Count Andrenyi]]
- **Witness** : [[M. Bouc]]
- **Witness** : [[Hildegarde Schmidt]]
- **Witness** : [[Greta Ohlsson]]
- **Witness** : [[The Valet]]
- **Witness** : [[Countess Andrenyi]]
- **Witness** : [[Antonio Foscarelli]]
- **Witness** : [[Princess Dragonmiroff]]
- **Witness** : [[Dr. Constantine]]
- **Witness** : [[Cyrus Hardman]]
- **Witness** : [[Mrs Hubbard]]
- **Witness** : [[Hector MacQueen]]
- **Clue** : [[No Footprints]]
- **Witness** : [[The Conductor]]
- **Witness** : [[Mary Debenham]]
- **Participant** : [[Hercule Poirot]]
