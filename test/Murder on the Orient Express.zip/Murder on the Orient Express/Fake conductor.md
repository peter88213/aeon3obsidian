Imposter

Described as a small, dark man with a feminine voice by Hardman, which is later confirmed by Hildegarde Schmidt.

- Relates to: [[Intruder in Mrs Hubbard’s apartment]]

- Witness: [[Hardman]]

- Witness: [[Hildegarde]]

- Witness: [[MacQueen]]

- Witness: [[Arbuthnot]]